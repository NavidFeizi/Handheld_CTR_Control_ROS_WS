// Discrete motion validator for CTR: checks interpolated states along an edge
// for mechanical ordering constraints (beta sequence) and (future) anatomical
// collisions. Uses SpaceInformation's state allocation utilities and reuses a
// single temporary state for efficiency.

#pragma once

#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/SpaceInformation.h>
#include <ompl/base/StateValidityChecker.h>
#include <ompl/base/DiscreteMotionValidator.h>
#include <ompl/util/Console.h>
#include <cmath>
#include <algorithm>
#include <limits>
#include "PINNs.hpp"

template <size_t Nodes, size_t controlInputs>
class CTR_DiscreteMotionValidator : public ompl::base::DiscreteMotionValidator
{
public:
    CTR_DiscreteMotionValidator(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs> &_ctr);

    // Basic motion check (OMPL will call the 3-arg variant optionally); we
    // override the 2-arg and let the base class handle lastValid bookkeeping.
    bool checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const override;

    void setGoalBetas(double b1, double b2, double b3);

private:
    PINNs<Nodes, controlInputs> &m_ctr;
    double m_Clr{0.0}; // clearance radius between prismatic segments
    double beta1_goal{0.0}, beta2_goal{0.0}, beta3_goal{0.0};
    mutable bool goalBetasSet{false};
    static constexpr double goalTolerance{1.00E-6}; // tolerance for goal comparison
};

// ============================= Implementation =============================

template <size_t Nodes, size_t controlInputs>
CTR_DiscreteMotionValidator<Nodes, controlInputs>::CTR_DiscreteMotionValidator(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs> &_ctr)
    : ompl::base::DiscreteMotionValidator(si), m_ctr(_ctr)
{
    m_Clr = _ctr.getStageThickness();
}

template <size_t Nodes, size_t controlInputs>
bool CTR_DiscreteMotionValidator<Nodes, controlInputs>::checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const
{
    // If goal betas are not set we cannot enforce deployment-phase monotonicity.
    // Emit a one-time warning and continue with structural-validity-only checks.
    if (!goalBetasSet)
        OMPL_WARN("CTR_DiscreteMotionValidator: checkMotion called before setGoalBetas(). "
                  "Deployment-phase monotonicity will not be enforced. "
                  "Call Planner::setGoalState() before solving.");

    // Quick validity of endpoints
    if (!si_->isValid(s1) || !si_->isValid(s2))
        return false;

    // If identical states, treat as valid
    if (si_->getStateSpace()->equalStates(s1, s2))
        return true;

    // Derive the number of intermediate checks from the space's segment length
    // settings (longestValidSegmentFraction) so check density scales correctly
    // with motion length, consistent with OMPL's DiscreteMotionValidator.
    const auto nd = static_cast<unsigned int>(si_->getStateSpace()->validSegmentCount(s1, s2));

    auto *tmp = si_->getStateSpace()->allocState();

    bool beta3Reached = false;
    bool beta2Reached = false;

    for (unsigned int i = 1; i < nd; ++i)
    {
        const double t = static_cast<double>(i) / static_cast<double>(nd);
        si_->getStateSpace()->interpolate(s1, s2, t, tmp);

        const auto *rv = tmp->as<ompl::base::RealVectorStateSpace::StateType>();
        const double b1 = rv->values[0UL];
        const double b2 = rv->values[1UL];
        const double b3 = rv->values[2UL];

        // Mechanical ordering constraints with clearance
        if (b1 > b2 - m_Clr || b2 > b3 - m_Clr)
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }

        // Deployment-phase monotonicity: once a tube reaches its goal length,
        // forbid retraction. Only enforced when goal betas are known.
        if (goalBetasSet)
        {
            if (!beta3Reached && std::fabs(b3 - beta3_goal) <= goalTolerance)
                beta3Reached = true;
            if (beta3Reached && b3 < beta3_goal - goalTolerance)
            {
                si_->getStateSpace()->freeState(tmp);
                return false;
            }

            if (!beta2Reached && std::fabs(b2 - beta2_goal) <= goalTolerance)
                beta2Reached = true;
            if (beta2Reached && b2 < beta2_goal - goalTolerance)
            {
                si_->getStateSpace()->freeState(tmp);
                return false;
            }
        }

        // Additional constraints from the validity checker (e.g. collisions)
        if (!si_->isValid(tmp))
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }
    }

    si_->getStateSpace()->freeState(tmp);
    return true;
}

template <size_t Nodes, size_t controlInputs>
void CTR_DiscreteMotionValidator<Nodes, controlInputs>::setGoalBetas(double b1, double b2, double b3)
{
    beta1_goal = b1;
    beta2_goal = b2;
    beta3_goal = b3;
    goalBetasSet = true;
}