#ifndef PINNS_HPP
#define PINNS_HPP

#include <torch/torch.h>
#include <torch/script.h>

#include <blaze/Math.h>

#include <filesystem>
#include <iostream>
#include <memory>
#include <cassert>
#include <cmath>
#include <fstream>
#include <sstream>
#include <array>
#include <vector>
#include <type_traits>
#include <iomanip>
#include <algorithm>
// #include <mutex> // no longer needed with thread_local buffers

#include <nlohmann/json.hpp>

// Custom exception for parameter loading errors
struct ParameterLoadError : public std::runtime_error
{
    using std::runtime_error::runtime_error;
};

struct PhysicsParameters
{
    std::vector<double> E, G, rc, Ls, Lc, Do, Di, L;
};

struct ModelParameters
{
    std::vector<int> tau_index;
    std::vector<int> layers;
};

struct DatasetParameters
{
    std::array<double, 2UL> beta1_range;
    std::array<double, 2UL> beta2_range;
    std::array<double, 2UL> beta3_range;
    std::array<double, 2UL> alpha1_range;
    std::array<double, 2UL> alpha2_range;
    std::array<double, 2UL> alpha3_range;
};

namespace detail
{

    inline std::vector<int> vec_int_or_throw(const nlohmann::json &obj, const char *key)
    {
        if (!obj.contains(key))
            throw ParameterLoadError(std::string("Missing key '") + key + "' in model_params");
        const auto &v = obj.at(key);
        if (!v.is_array())
            throw ParameterLoadError(std::string("Key '") + key + "' must be an array");

        std::vector<int> out;
        out.reserve(v.size());
        for (size_t i = 0; i < v.size(); ++i)
        {
            if (!v[i].is_number_integer())
                throw ParameterLoadError(std::string("Key '") + key + "' element " + std::to_string(i) + " is not an integer");
            out.emplace_back(v[i].get<int>());
        }
        return out;
    }

    inline std::vector<double> vec_double_or_throw(const nlohmann::json &obj, const char *key)
    {
        if (!obj.contains(key))
            throw ParameterLoadError(std::string("Missing key '") + key + "' in model_params");
        const auto &v = obj.at(key);
        if (!v.is_array())
            throw ParameterLoadError(std::string("Key '") + key + "' must be an array");

        std::vector<double> out;
        out.reserve(v.size());
        for (size_t i = 0; i < v.size(); ++i)
        {
            if (!v[i].is_number())
                throw ParameterLoadError(std::string("Key '") + key + "' element " + std::to_string(i) + " is not a number");
            out.emplace_back(v[i].get<double>());
        }
        return out;
    }

} // namespace detail

// PINNs class
template <size_t Nodes, size_t controlInputs>
class PINNs
{
public:
    // Constructor takes model name
    explicit PINNs(std::string model_name);

    // Disable copy to avoid accidental heavy copies (shared_ptr for module is cheap)
    PINNs(const PINNs &) = default;
    PINNs &operator=(const PINNs &) = default;

    // Move allowed
    PINNs(PINNs &&) = default;
    PINNs &operator=(PINNs &&) = default;

    // Public inference API
    void get_pos_distal(const blaze::StaticVector<double, controlInputs> &tau,
                        blaze::StaticVector<double, 3UL> &pos) const;

    void get_pos_tubes(const blaze::StaticVector<double, controlInputs> &tau,
                       blaze::StaticVector<double, 3UL> &pos_t3,
                       blaze::StaticVector<double, 3UL> &pos_t2,
                       blaze::StaticVector<double, 3UL> &pos_t1) const;

    void get_shape(const blaze::StaticVector<double, controlInputs> &tau,
                   blaze::StaticMatrix<double, Nodes, 3UL> &states) const;

    void get_entire_state(const blaze::StaticVector<double, controlInputs> &tau,
                          blaze::StaticMatrix<double, Nodes, 15UL> &states) const;

    // function that cmoputes the Jacobian of spatial velocities at the distal-end of the CTR
    void jacobian(const blaze::StaticVector<double, controlInputs> &tau, blaze::StaticMatrix<double, 3UL, controlInputs, blaze::columnMajor> &J);

    // function that implements the inverse kinematics for the CTR
    void posCTRL(blaze::StaticVector<double, controlInputs> &tau, const blaze::StaticVector<double, 3UL> &target, const double posTol);

    [[nodiscard]] blaze::StaticVector<double, 3UL> get_s_ends(const blaze::StaticVector<double, controlInputs> &tau) const;

    // function that returns the lengths of the straight sections of the CTR component tubes
    [[nodiscard]] blaze::StaticVector<double, 3UL> getStraightLen() const;

    // function that returns the overall lengths of the CTRcomponent tubes
    [[nodiscard]] blaze::StaticVector<double, 3UL> getOverallLen() const;

    // function that returns the allowable range of travel for the prismatic joints of the CTR
    [[nodiscard]] blaze::StaticVector<double, controlInputs> getPrismaticJointRanges() const;

    // function that returns the allowable range of travel for the revolute joints of the CTR
    [[nodiscard]] blaze::StaticVector<double, controlInputs> getRevoluteJointRanges() const;

    // function that returns the stage thickness of the linear guide actuators
    [[nodiscard]] double getStageThickness() const;

    // function that returns the number of nodes (discrete points) along the CTR backbone
    [[nodiscard]] size_t getNumNodes() const;

    // Optional: print a human readable summary (kept out of constructor)
    void print_summary(std::ostream &os = std::cout) const;

    blaze::StaticMatrix<double, 6UL, 3UL, blaze::columnMajor> pInv(const blaze::StaticMatrix<double, 3UL, 6UL, blaze::columnMajor> &M);

private:
    // constants for layout
    static constexpr size_t kStateDim = 15UL;
    static constexpr size_t kPositionStartCol = 8UL;
    static constexpr size_t kOutDim = 3UL;

    // model
    std::shared_ptr<torch::jit::Module> m_dnn;
    PhysicsParameters m_physics_params{};
    ModelParameters m_model_params{};
    DatasetParameters m_dataset_params{};

    // Per-thread inference buffers to avoid cross-thread races without coarse locks
    struct Buffers
    {
        torch::Tensor s_buffer;
        torch::Tensor tau_row_buffer;
        torch::Tensor tau_cols_buffer;
        torch::Tensor input_buffer;
        torch::Tensor output_buffer; // optional reuse for outputs
    };
    inline static thread_local Buffers tls_{};

    // helper
    torch::Tensor get_input_tensor(const blaze::StaticVector<double, controlInputs> &tau) const;
    void load_model_parameters(const std::string &params_path);
    std::shared_ptr<torch::jit::Module> load_model(const std::string &path) const;

    // utility
    static void ensure_buffers_for_nodes(size_t nodes, size_t k);
    std::string model_name_;
    std::string models_dir_;
};

// ============================= Implementation =============================

template <size_t Nodes, size_t controlInputs>
PINNs<Nodes, controlInputs>::PINNs(std::string model_name)
    : model_name_(std::move(model_name))
{
    // conservative default for inference threads; can be overridden by caller
    torch::set_num_threads(2);

    this->models_dir_ = models_Directory;
    const std::filesystem::path model_dir = std::filesystem::path(models_dir_) / model_name_;

    // Load the parameters
    const std::string params_path = (model_dir / "parameters.json").string();
    load_model_parameters(params_path);

    // Load the scripted module (CPU)
    const std::string model_path = (model_dir / "model_scripted.pt").string();
    m_dnn = load_model(model_path);

    // Thread-local buffers are created lazily per thread; no shared buffers here.

    // // call print_summary to print to console
    // print_summary(std::cout);
}

// ensure internal torch buffers have sizes compatible with nodes and k (num tau inputs)
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::ensure_buffers_for_nodes(size_t nodes, size_t k)
{
    // s_buffer : (nodes,1)
    if (!tls_.s_buffer.defined() || tls_.s_buffer.sizes() != torch::IntArrayRef{static_cast<long>(nodes), 1})
        tls_.s_buffer = torch::empty({static_cast<long>(nodes), 1}, torch::TensorOptions().dtype(torch::kFloat64));

    // tau_row_buffer : (1,k)
    if (!tls_.tau_row_buffer.defined() || tls_.tau_row_buffer.sizes() != torch::IntArrayRef{1, static_cast<long>(k)})
        tls_.tau_row_buffer = torch::empty({1, static_cast<long>(k)}, torch::TensorOptions().dtype(torch::kFloat64));

    // tau_cols_buffer : (nodes,k)
    if (!tls_.tau_cols_buffer.defined() || tls_.tau_cols_buffer.sizes() != torch::IntArrayRef{static_cast<long>(nodes), static_cast<long>(k)})
        tls_.tau_cols_buffer = torch::empty({static_cast<long>(nodes), static_cast<long>(k)}, torch::TensorOptions().dtype(torch::kFloat64));

    // input_buffer : (nodes, 1+k)
    if (!tls_.input_buffer.defined() || tls_.input_buffer.sizes() != torch::IntArrayRef{static_cast<long>(nodes), static_cast<long>(1 + k)})
        tls_.input_buffer = torch::empty({static_cast<long>(nodes), static_cast<long>(1 + k)}, torch::TensorOptions().dtype(torch::kFloat64));
}

// get_input_tensor: writes directly into a freshly allocated 1xK tensor
template <size_t Nodes, size_t controlInputs>
torch::Tensor PINNs<Nodes, controlInputs>::get_input_tensor(
    const blaze::StaticVector<double, controlInputs> &tau) const
{
    const size_t K = m_model_params.tau_index.size();

    // Ensure internal buffer is the right shape (1 x K)
    ensure_buffers_for_nodes(1, K);

    // Fast access to the internal tensor's data via torch accessor
    auto acc = tls_.tau_row_buffer.template accessor<double, 2>();

    // Direct pointer to the blaze vector data (avoids any memcpy and is alignment-friendly)
    const double *tau_ptr = tau.data();
    const size_t tau_size = tau.size();

    for (size_t i = 0; i < K; ++i)
    {
        int idx_signed = m_model_params.tau_index[i];
        if (idx_signed < 0)
            throw ParameterLoadError("tau_index contains negative index at position " + std::to_string(i) +
                                     ": " + std::to_string(idx_signed));

        const size_t idx = static_cast<size_t>(idx_signed);
        if (idx >= tau_size)
            throw ParameterLoadError("tau_index contains out-of-range index at position " + std::to_string(i) +
                                     ": " + std::to_string(idx));

        acc[0][i] = tau_ptr[idx];
    }

    // Return a shallow clone so caller modifications won't affect the internal buffer.
    return tls_.tau_row_buffer.clone();
}

// load model
template <size_t Nodes, size_t controlInputs>
std::shared_ptr<torch::jit::Module> PINNs<Nodes, controlInputs>::load_model(const std::string &model_path) const
{
    if (!std::filesystem::exists(model_path) || !std::filesystem::is_regular_file(model_path))
        throw std::runtime_error("FATAL: model file not found: " + model_path);

    // load module on CPU
    auto module = std::make_shared<torch::jit::Module>(torch::jit::load(model_path, torch::kCPU));

    return module;
}

// parameter loading
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::load_model_parameters(const std::string &params_path)
{
    std::ifstream file(params_path);
    if (!file.is_open())
        throw ParameterLoadError("Could not open parameters file: " + params_path);

    nlohmann::json json_data;
    file >> json_data;

    if (!json_data.contains("physics_params") || !json_data["physics_params"].is_object())
        throw ParameterLoadError("Missing or invalid 'physics_params' section in JSON file");

    const auto &physics = json_data["physics_params"];
    this->m_physics_params.E = detail::vec_double_or_throw(physics, "young_modulus");
    this->m_physics_params.G = detail::vec_double_or_throw(physics, "shear_modulus");
    this->m_physics_params.rc = detail::vec_double_or_throw(physics, "curve_radius");
    this->m_physics_params.Ls = detail::vec_double_or_throw(physics, "straight_length");
    this->m_physics_params.Lc = detail::vec_double_or_throw(physics, "curve_length");
    this->m_physics_params.Do = detail::vec_double_or_throw(physics, "outer_diameter");
    this->m_physics_params.Di = detail::vec_double_or_throw(physics, "inner_diameter");

    // compute L
    this->m_physics_params.L.clear();
    this->m_physics_params.L.reserve(3);
    for (size_t i = 0; i < 3; ++i)
    {
        if (i >= this->m_physics_params.Ls.size() || i >= this->m_physics_params.Lc.size())
            throw ParameterLoadError("physics_params arrays must have at least 3 elements");
        this->m_physics_params.L.emplace_back(this->m_physics_params.Ls[i] + this->m_physics_params.Lc[i]);
    }

    // model params
    if (!json_data.contains("model_params") || !json_data["model_params"].is_object())
        throw ParameterLoadError("Missing or invalid 'model_params' section in JSON file");

    const auto &model = json_data["model_params"];
    this->m_model_params.tau_index = detail::vec_int_or_throw(model, "tau_idx");
    this->m_model_params.layers = detail::vec_int_or_throw(model, "layers");

    // dataset params
    if (!json_data.contains("dataset_params") || !json_data["dataset_params"].is_object())
        throw ParameterLoadError("Missing or invalid 'dataset_params' section in JSON file");

    const auto &dataset = json_data["dataset_params"];
    this->m_dataset_params.beta1_range = {dataset.at("beta1_range").at(0).get<double>(), dataset.at("beta1_range").at(1).get<double>()};
    this->m_dataset_params.beta2_range = {dataset.at("beta2_range").at(0).get<double>(), dataset.at("beta2_range").at(1).get<double>()};
    this->m_dataset_params.beta3_range = {dataset.at("beta3_range").at(0).get<double>(), dataset.at("beta3_range").at(1).get<double>()};

    // accounting for Navid's weird parametrization LOL
    this->m_dataset_params.beta1_range[0UL] += this->m_dataset_params.beta2_range[0UL];
    this->m_dataset_params.beta1_range[1UL] += this->m_dataset_params.beta2_range[1UL];

    this->m_dataset_params.alpha1_range = {dataset.at("alpha1_range").at(0).get<double>(), dataset.at("alpha1_range").at(1).get<double>()};
    // this->m_dataset_params.alpha2_range = {dataset.at("alpha2_range").at(0).get<double>(), dataset.at("alpha2_range").at(1).get<double>()};
    this->m_dataset_params.alpha3_range = {dataset.at("alpha3_range").at(0).get<double>(), dataset.at("alpha3_range").at(1).get<double>()};

    // accounting for Navid's relative parametrization of the revolute joint for intermediate tube
    this->m_dataset_params.alpha2_range[0UL] = this->m_dataset_params.alpha1_range[0UL] - M_PI;
    this->m_dataset_params.alpha2_range[1UL] = this->m_dataset_params.alpha1_range[1UL] + M_PI;
}

// print summary
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::print_summary(std::ostream &os) const
{
    os << "Model: " << model_name_ << std::endl
       << std::endl;
    os << "Physics parameters: " << std::endl;
    auto print_vec = [&os](const char *name, const auto &vec)
    {
        using T = typename std::decay_t<decltype(vec)>::value_type;
        os << name << ": [";
        for (size_t i = 0; i < vec.size(); ++i)
        {
            if constexpr (std::is_floating_point_v<T>)
                os << std::setprecision(6) << vec[i];
            else
                os << vec[i];
            if (i + 1 < vec.size())
                os << ", ";
        }
        os << "]" << std::endl;
    };
    print_vec("E", m_physics_params.E);
    print_vec("G", m_physics_params.G);
    print_vec("rc", m_physics_params.rc);
    print_vec("Ls", m_physics_params.Ls);
    print_vec("Lc", m_physics_params.Lc);
    print_vec("Do", m_physics_params.Do);
    print_vec("Di", m_physics_params.Di);
    print_vec("L", m_physics_params.L);

    os << std::endl;
    os << "Model parameters:" << std::endl;
    print_vec("layers", m_model_params.layers);
    print_vec("tau_index", m_model_params.tau_index);

    os << std::endl;
    os << "Dataset parameters -- Actuation Limits:" << std::endl;
    os << "beta1_range: [" << m_dataset_params.beta1_range[0UL] << ", " << m_dataset_params.beta1_range[1UL] << "]" << std::endl;
    os << "beta2_range: [" << m_dataset_params.beta2_range[0UL] << ", " << m_dataset_params.beta2_range[1UL] << "]" << std::endl;
    os << "beta3_range: [" << m_dataset_params.beta3_range[0UL] << ", " << m_dataset_params.beta3_range[1UL] << "]" << std::endl;
    os << "alpha1_range: [" << m_dataset_params.alpha1_range[0UL] << ", " << m_dataset_params.alpha1_range[1UL] << "]" << std::endl;
    os << "alpha2_range: [" << m_dataset_params.alpha2_range[0UL] << ", " << m_dataset_params.alpha2_range[1UL] << "]" << std::endl;
    os << "alpha3_range: [" << m_dataset_params.alpha3_range[0UL] << ", " << m_dataset_params.alpha3_range[1UL] << "]" << std::endl;

    os << "----------------- PINNs Summary ----------------\n"
       << std::endl;
}

// get_s_ends
template <size_t Nodes, size_t controlInputs>
blaze::StaticVector<double, 3UL> PINNs<Nodes, controlInputs>::get_s_ends(const blaze::StaticVector<double, controlInputs> &tau) const
{
    return {
        m_physics_params.L[0UL] + tau[0UL],
        m_physics_params.L[1UL] + tau[1UL],
        m_physics_params.L[2UL] + tau[2UL]};
}

// getStraightLen
template <size_t Nodes, size_t controlInputs>
blaze::StaticVector<double, 3UL> PINNs<Nodes, controlInputs>::getStraightLen() const
{
    return {
        m_physics_params.Ls[0UL],
        m_physics_params.Ls[1UL],
        m_physics_params.Ls[2UL]};
}

// getStraightLen
template <size_t Nodes, size_t controlInputs>
blaze::StaticVector<double, 3UL> PINNs<Nodes, controlInputs>::getOverallLen() const
{
    return {
        m_physics_params.Ls[0UL] + m_physics_params.Lc[0UL],
        m_physics_params.Ls[1UL] + m_physics_params.Lc[1UL],
        m_physics_params.Ls[2UL] + m_physics_params.Lc[2UL]};
}

// function that returns the allowable range of travel for the prismatic joints of the CTR
template <size_t Nodes, size_t controlInputs>
blaze::StaticVector<double, controlInputs> PINNs<Nodes, controlInputs>::getPrismaticJointRanges() const
{
    return {
        m_dataset_params.beta1_range[0UL], m_dataset_params.beta1_range[1UL],  // min, max
        m_dataset_params.beta2_range[0UL], m_dataset_params.beta2_range[1UL],  // min, max
        m_dataset_params.beta3_range[0UL], m_dataset_params.beta3_range[1UL]}; // min, max
}

// function that returns the allowable range of travel for the revolute joints of the CTR
template <size_t Nodes, size_t controlInputs>
blaze::StaticVector<double, controlInputs> PINNs<Nodes, controlInputs>::getRevoluteJointRanges() const
{
    return {
        m_dataset_params.alpha1_range[0UL], m_dataset_params.alpha1_range[1UL],  // min, max
        m_dataset_params.alpha2_range[0UL], m_dataset_params.alpha2_range[1UL],  // min, max
        m_dataset_params.alpha3_range[0UL], m_dataset_params.alpha3_range[1UL]}; // min, max
}

// function that returns the stage thickness of the linear guide actuators
template <size_t Nodes, size_t controlInputs>
double PINNs<Nodes, controlInputs>::getStageThickness() const
{
    return 30.00E-3; // 30 mm
}

// function that returns the number of discrete points along the CTR backbone
template <size_t Nodes, size_t controlInputs>
size_t PINNs<Nodes, controlInputs>::getNumNodes() const
{
    return Nodes;
}

// function that returns the distal end position of the CTR given actuation inputs tau
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::get_pos_distal(const blaze::StaticVector<double, controlInputs> &tau, blaze::StaticVector<double, 3UL> &pos) const
{
    // Use inference mode for best performance
    torch::InferenceMode inferred;

    const size_t K = m_model_params.tau_index.size();
    ensure_buffers_for_nodes(1, K);

    // prepare s value and tau_row
    const double s_val = m_physics_params.L[0UL] + tau[0UL];
    tls_.s_buffer.resize_({1, 1}).fill_(s_val);

    // reuse get_input_tensor but it clones the internal buffer
    auto tau_row = get_input_tensor(tau);

    // input: cat(s, tau_row)
    tls_.input_buffer.resize_({1, static_cast<long>(1 + K)});
    tls_.input_buffer.narrow(1, 0, 1).copy_(tls_.s_buffer);
    tls_.input_buffer.narrow(1, 1, static_cast<long>(K)).copy_(tau_row);

    auto states = m_dnn->forward({tls_.input_buffer}).toTensor();
    TORCH_CHECK(states.dim() == 2 && states.size(1) >= static_cast<long>(kPositionStartCol + kOutDim), "Unexpected model output shape in get_pos_distal");
    if (!states.is_contiguous())
        states = states.contiguous();

    const double *data = states.template data_ptr<double>();
    pos[0UL] = data[kPositionStartCol + 0UL];
    pos[1UL] = data[kPositionStartCol + 1UL];
    pos[2UL] = data[kPositionStartCol + 2UL];
}

// get_pos_tubes
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::get_pos_tubes(const blaze::StaticVector<double, controlInputs> &tau,
                                                blaze::StaticVector<double, 3UL> &pos_1,
                                                blaze::StaticVector<double, 3UL> &pos_2,
                                                blaze::StaticVector<double, 3UL> &pos_3) const
{
    torch::InferenceMode inferred;

    const size_t K = m_model_params.tau_index.size();
    ensure_buffers_for_nodes(3, K);

    // prepare s column (3x1)
    std::array<double, 3> svals{
        m_physics_params.L[2UL] + tau[2UL],
        m_physics_params.L[1UL] + tau[1UL],
        m_physics_params.L[0UL] + tau[0UL]};
    // safe construction of s tensor (owning memory)
    auto s = torch::tensor({svals[0], svals[1], svals[2]}, torch::TensorOptions().dtype(torch::kFloat64)).unsqueeze(1);

    // get tau_row and expand
    auto tau_row = get_input_tensor(tau); // cloned
    auto tau_cols = tau_row.expand({3, -1});

    // build input
    tls_.input_buffer.resize_({3, static_cast<long>(1 + K)});
    tls_.input_buffer.narrow(1, 0, 1).copy_(s);
    tls_.input_buffer.narrow(1, 1, static_cast<long>(K)).copy_(tau_cols);

    auto states = m_dnn->forward({tls_.input_buffer}).toTensor(); // (3, M)
    TORCH_CHECK(states.dim() == 2 && states.size(1) >= static_cast<long>(kPositionStartCol + kOutDim), "Unexpected model output shape in get_pos_tubes");
    auto pos = states.index({"...", torch::indexing::Slice(static_cast<long>(kPositionStartCol), static_cast<long>(kPositionStartCol + kOutDim))}); // (3,3)
    auto pos_a = pos.template accessor<double, 2>();

    for (size_t i = 0; i < kOutDim; ++i)
    {
        pos_1[i] = pos_a[0][i];
        pos_2[i] = pos_a[1][i];
        pos_3[i] = pos_a[2][i];
    }
}

// get_entire_state
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::get_entire_state(const blaze::StaticVector<double, controlInputs> &tau, blaze::StaticMatrix<double, Nodes, 15UL> &states) const
{
    torch::InferenceMode inferred;

    const size_t K = m_model_params.tau_index.size();
    ensure_buffers_for_nodes(Nodes, K);

    // s: linspace(0, L_tau, Nodes)
    const double L_tau = m_physics_params.L[0UL] + tau[0UL];
    tls_.s_buffer = torch::linspace(0.0, L_tau, static_cast<long>(Nodes), torch::TensorOptions().dtype(torch::kFloat64)).unsqueeze(1);

    // tau_row -> expanded
    auto tau_row = get_input_tensor(tau);
    auto tau_cols = tau_row.expand({static_cast<long>(Nodes), -1});

    tls_.input_buffer.resize_({static_cast<long>(Nodes), static_cast<long>(1 + K)});
    tls_.input_buffer.narrow(1, 0, 1).copy_(tls_.s_buffer);
    tls_.input_buffer.narrow(1, 1, static_cast<long>(K)).copy_(tau_cols);

    auto states_torch = m_dnn->forward({tls_.input_buffer}).toTensor();
    TORCH_CHECK(states_torch.dim() == 2 && states_torch.size(1) >= static_cast<long>(kStateDim), "Unexpected model output shape in get_entire_state");
    if (!states_torch.is_contiguous())
        states_torch = states_torch.contiguous();

    const double *torch_ptr = states_torch.template data_ptr<double>();
    double *blaze_ptr = &states(0, 0);

    // copy contiguous block
    std::copy(torch_ptr, torch_ptr + Nodes * kStateDim, blaze_ptr);
}

// compute Jacobian using torch's autograd
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::jacobian(const blaze::StaticVector<double, controlInputs> &tau,
                                           blaze::StaticMatrix<double, 3UL, controlInputs, blaze::columnMajor> &J)
{
    // create a torch tensor for the full tau vector and require gradients
    std::vector<double> tau_std(controlInputs);
    std::copy(tau.begin(), tau.end(), tau_std.begin());

    auto options = torch::TensorOptions().dtype(torch::kFloat64).device(torch::kCPU);
    torch::Tensor tau_t = torch::tensor(tau_std, options).set_requires_grad(true); // shape: [controlInputs]

    // build network input = [ s, tau_selected ], where s = L[0] + tau_t[0]
    const size_t K = m_model_params.tau_index.size();

    // build index tensor for selecting the tau inputs used by the network
    std::vector<int64_t> idx_vec;
    idx_vec.reserve(K);
    for (size_t i = 0; i < K; ++i)
    {
        int idx_signed = m_model_params.tau_index[i];
        if (idx_signed < 0)
            throw ParameterLoadError("tau_index contains negative index at index " + std::to_string(i) + ": " + std::to_string(idx_signed));
        idx_vec.emplace_back(static_cast<int64_t>(idx_signed));
    }
    auto idx_tensor = torch::from_blob(idx_vec.data(), {static_cast<long>(K)}, torch::TensorOptions().dtype(torch::kInt64)).clone();

    // select the K entries used by the model
    torch::Tensor tau_selected = torch::index_select(tau_t, 0, idx_tensor); // shape: [K]

    // compute s as a tensor depending on tau_t[0], so gradient flows through it
    // s = L_tau = L[0] + tau[0]
    const double L0 = m_physics_params.L[0UL];
    torch::Tensor s = tau_t.index({0}) + L0; // shape: scalar tensor, requires_grad true because tau_t requires_grad

    // assemble input: make it shape [1, 1+K]
    torch::Tensor input = torch::cat({s.unsqueeze(0).unsqueeze(1), tau_selected.unsqueeze(0)}, 1); // shape: [1, 1+K]

    // Forward pass (no InferenceMode / NoGrad since we need autograd graph)
    torch::Tensor states = m_dnn->forward({input}).toTensor(); // (1, M)
    TORCH_CHECK(states.dim() == 2 && states.size(1) >= static_cast<long>(kPositionStartCol + kOutDim),
                "Unexpected model output shape in jacobian");

    // Compute gradients for each position component
    // prepare grad_outputs scalar = 1.0 for each scalar output
    torch::TensorOptions scalar_opts = torch::TensorOptions().dtype(torch::kFloat64).device(torch::kCPU);
    // We'll compute each component's grads separately; retain_graph for the first two calls.
    for (size_t j = 0; j < kOutDim; ++j)
    {
        // pick the scalar output: states[0, kPositionStartCol + j]
        torch::Tensor out = states.index({0, static_cast<long>(kPositionStartCol + j)}); // scalar tensor

        // grad_outputs must match shape of out (scalar)
        std::vector<torch::Tensor> grad_outputs = {torch::ones_like(out, scalar_opts)};

        // compute grad(out, tau_t) ; allow_unused=true to avoid exceptions if some tau entries do not affect the output
        bool retain_graph = (j < kOutDim - 1); // keep graph for first k-1 computations
        std::vector<torch::Tensor> grads;
        try
        {
            grads = torch::autograd::grad(
                /*outputs=*/{out},
                /*inputs=*/{tau_t},
                /*grad_outputs=*/grad_outputs,
                /*retain_graph=*/retain_graph,
                /*create_graph=*/false,
                /*allow_unused=*/true);
        }
        catch (const std::exception &e)
        {
            // If autograd fails for some reason, fall back to zero-gradient column (safe)
            for (size_t i = 0; i < controlInputs; ++i)
                J(j, i) = 0.00;
            continue;
        }

        // grads[0] corresponds to grad(out) / grad(tau_t) and can be undefined if an input wasn't used.
        if (grads.empty() || !grads[0].defined())
        {
            // fill zeros
            for (size_t i = 0; i < controlInputs; ++i)
                J(j, i) = 0.00;
        }
        else
        {
            // grads[0] is a 1-D tensor of length controlInputs
            auto g = grads[0].contiguous();
            // if some entries are undefined (shouldn't be the case with allow_unused=true and defined returned), it's safe to check and substitute 0.0
            if (g.numel() != static_cast<long>(controlInputs))
            {
                for (size_t i = 0; i < controlInputs; ++i)
                    J(j, i) = 0.00;
            }
            else
            {
                auto acc = g.accessor<double, 1>();
                for (size_t i = 0; i < controlInputs; ++i)
                    J(j, i) = acc[static_cast<long>(i)];
            }
        }
    }
}

// // function that computes the Jacobian of spatial velocities at the distal-end of the CTR  ===>> FINITE DIFFERENCES <<===
// template <size_t Nodes, size_t controlInputs>
// void PINNs<Nodes, controlInputs>::jacobian(const blaze::StaticVector<double, controlInputs> &tau, blaze::StaticMatrix<double, 3UL, controlInputs, blaze::columnMajor> &J)
// {
//     // stores the distal end position
//     blaze::StaticVector<double, 3UL> tipPos, currentTipPos;
//     // stores the indices of tubes to be actuated (inner and intermediate tubes only)
//     static constexpr std::array<size_t, 4UL> actuators = {0, 1, 3, 4};
//     // infinitesimal amount for finite differences
//     static constexpr double eps = 1.00E-4;
//     // current tip position
//     this->get_pos_distal(tau, currentTipPos);
//     // perturbed CTR joints for computing the finite-differences Jacobian
//     blaze::StaticVector<double, controlInputs> tau_Perturbed(tau);

//     // iterating through all joints in the CTR for computing the Jacobian:
//     for (auto &el : actuators)
//     {
//         tau_Perturbed[el] += eps;
// 		// computing the distal-end position after perturbing the i-th CTR joint
//         this->get_pos_distal(tau_Perturbed, tipPos);

// 		// computing the tip position of the perturbed CTR
// 		blaze::column(J, el) = (tipPos - currentTipPos) / eps;
// 		// restoring the original CTR joint values
// 		tau_Perturbed[el] = tau[el];
//     }

//     return;
// }

// function that implements the inverse kinematics based on resolved ratse motion of the CTR
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::posCTRL(blaze::StaticVector<double, controlInputs> &tau, const blaze::StaticVector<double, 3UL> &target, const double posTol)
{
    double minError = 1.00E3;                                           // minimum distance to target
    blaze::StaticMatrix<double, 3UL, 6UL, blaze::columnMajor> J;        // Jacobian matrix
    blaze::StaticMatrix<double, 6UL, 3UL, blaze::columnMajor> J_inv;    // Jacobian pseudoinverse
    constexpr blaze::IdentityMatrix<double, blaze::columnMajor> I(6UL); // 6 x 6 Identity matrix

    // proportional, derivative, and integral gains for position control
    constexpr double kp = 1.000, ki = 0.0005, kd = 0.0001;

    const blaze::DiagonalMatrix<blaze::StaticMatrix<double, 3UL, 3UL, blaze::columnMajor>> Kp{
        {kp, 0.00, 0.00},
        {0.00, kp, 0.00},
        {0.00, 0.00, kp}};

    const blaze::DiagonalMatrix<blaze::StaticMatrix<double, 3UL, 3UL, blaze::columnMajor>> Ki{
        {ki, 0.00, 0.00},
        {0.00, ki, 0.00},
        {0.00, 0.00, ki}};

    const blaze::DiagonalMatrix<blaze::StaticMatrix<double, 3UL, 3UL, blaze::columnMajor>> Kd{
        {kd, 0.00, 0.00},
        {0.00, kd, 0.00},
        {0.00, 0.00, kd}};

    // Capturing the CTR's current joint configuration
    blaze::StaticVector<double, controlInputs> dtau_dt;
    blaze::reset(dtau_dt);
    blaze::StaticVector<double, controlInputs> tau_min(tau);

    blaze::StaticVector<double, 3UL> x_CTR;

    this->get_pos_distal(tau, x_CTR);

    blaze::StaticVector<double, 3UL> tipError = target - x_CTR;
    blaze::StaticVector<double, 3UL> last_tipError = tipError;
    blaze::StaticVector<double, 3UL> d_tipError{0.00, 0.00, 0.00};
    blaze::StaticVector<double, 3UL> int_tipError{0.00, 0.00, 0.00};
    static constexpr double integralClamp = 5.00; // meters (tip space) worth of integrator action per axis

    // Euclidean distance to target
    double dist2Tgt = blaze::norm(tipError);

    if (dist2Tgt < minError)
    {
        minError = dist2Tgt;
        tau_min = tau;

        if (dist2Tgt <= posTol)
            return;
    }

    // function to implement actuators sigularity avoidance
    blaze::StaticVector<double, 6UL> f;
    blaze::reset(f);
    auto f1 = blaze::subvector<0UL, 3UL>(f);

    // lower and upper bounds on prismatic joint limits
    blaze::StaticVector<double, 3UL> betaMax, betaMin;

    // iterations counter
    size_t N_itr = 0UL;
    // maximum admissible number of iterations in the position control loop
    static constexpr size_t maxIter = 500UL;
    // parameters for local optimization (joint limits avoidance)
    static constexpr double ke = 4.00;

    const blaze::StaticVector<double, 3UL> L = this->getOverallLen();
    const blaze::StaticVector<double, 3UL> Ls = this->getStraightLen();
    const double stageThickness = this->getStageThickness();
    blaze::StaticVector<double, 3UL> beta;

    // position control loop
    while ((dist2Tgt > posTol) && (N_itr < maxIter))
    {
        // incrementing the number of iterations
        N_itr++;

        beta[0UL] = tau[0UL];
        beta[1UL] = tau[1UL];
        beta[2UL] = tau[2UL];

        // compute the Jacobian in the present configuration
        this->jacobian(tau, J);

        // Pseudo-inverse of Jacobian for resolving CTR joint motion rates
        J_inv = this->pInv(J);

        // Nullspace control (collision and actuation limits)
        betaMin[0UL] = std::max({-Ls[0UL], L[1UL] + beta[1UL] - L[0UL], L[2UL] + beta[2UL] - L[0UL]});
        betaMin[1UL] = std::max({-Ls[2UL], beta[0UL] + stageThickness, L[2UL] + beta[2UL] - L[1UL]});
        betaMin[2UL] = std::max(-Ls[2UL], beta[1UL] + stageThickness);

        betaMax[0UL] = beta[1UL] - stageThickness;
        betaMax[1UL] = std::min(beta[2UL] - stageThickness - 4e-3, L[0UL] + beta[0UL] - L[1UL]);
        betaMax[2UL] = std::min(L[1UL] + beta[1UL] - L[2UL], L[0UL] + beta[0UL] - L[2UL]);

        // penalty function for local optimization (actuator collision avoidance)
        constexpr double spanEps = 1.00E-6;
        blaze::StaticVector<double, 3UL> span = betaMax - betaMin;
        for (size_t i = 0; i < 3UL; ++i)
        {
            const double magnitude = std::max(std::abs(span[i]), spanEps);
            span[i] = std::copysign(magnitude, span[i]);
        }
        const auto normalizedOffset = (betaMax + betaMin - 2.00 * beta) / span;
        f1 = blaze::pow(blaze::abs(normalizedOffset), ke) * blaze::sign(beta - (betaMax + betaMin) * 0.50);

        // resolved rates -- Nullspacec local optimization (joint limit avoidance)
        const auto nullspaceProjector = I - (J_inv * J);
        const auto taskSpaceCommand = Kp * tipError + Kd * d_tipError + Ki * int_tipError;
        dtau_dt = J_inv * taskSpaceCommand - nullspaceProjector * f;

        // rescaling linear joint variables for limit avoidance
        auto rescale_dtau_dt = [&]() -> void
        {
            for (size_t i = 0; i < 3UL; ++i)
            {
                const double proposed = tau[i] + dtau_dt[i];
                if (proposed > betaMax[i])
                {
                    dtau_dt[i] = (betaMax[i] - tau[i]) * 0.50;
                }
                else if (proposed < betaMin[i])
                {
                    dtau_dt[i] = (betaMin[i] - tau[i]) * 0.50;
                }
            }
        };

        rescale_dtau_dt();

        // updating the CTR joints->q: [beta, theta]
        tau += dtau_dt;

        // Helper: wrap an angle to any [low, high) interval
        auto wrapToRange = [](double theta, double low, double high) -> double
        {
            const double width = high - low;
            const double inv_width = 1.00 / width;
            return low + (theta - low) - width * std::floor((theta - low) * inv_width);
        };

        // beta[3] (outermost tube) remains unactuated
        tau[2UL] = 0.00;
        // alpha[3] (outermost tube) remains unactuated
        tau[5UL] = 0.00;
        // tau[4] in [-1.5PI, 1.5PI]
        tau[4UL] = wrapToRange(tau[4UL], -1.50 * M_PI, 1.50 * M_PI);
        // tau[3] ∈ [tau[4] - PI, tau[4] + PI]
        tau[3UL] = wrapToRange(tau[3UL], tau[4UL] - M_PI, tau[4UL] + M_PI);

        // tip position as predicted by the model
        this->get_pos_distal(tau, x_CTR);

        // current position error
        tipError = target - x_CTR;
        // integrating the position error with simple anti-windup clamp
        int_tipError += tipError;
        int_tipError = blaze::map(int_tipError, [](double value)
                                  { return std::clamp(value, -integralClamp, integralClamp); });
        // derivative of the position error
        d_tipError = tipError - last_tipError;
        // updating the last tip error variable
        last_tipError = tipError;

        dist2Tgt = blaze::norm(tipError);

        if (dist2Tgt < minError)
        {
            minError = dist2Tgt;
            tau_min = tau;
        }

        // stops the control loop when the position update becomes significantly small
        if (blaze::linfNorm(dtau_dt) <= 1.00E-6)
        {
            // std::cout << "Exited out of position control loop due small incremental threshold!" << std::endl;

            tau = tau_min;
            return;
        }
    }

    // std::cout << "iteration " << N_itr << " out of " << maxIter << "\t error: " << dist2Tgt * 1.00E3 << " mm" << std::endl;

    tau = tau_min;

    // std::cout << "___________________________________\n" << std::endl;

    return;
}

// Forward Kinematics ==> get the entire shape of the CTR backbone for an actuation tau
template <size_t Nodes, size_t controlInputs>
void PINNs<Nodes, controlInputs>::get_shape(const blaze::StaticVector<double, controlInputs> &tau, blaze::StaticMatrix<double, Nodes, 3UL> &shape) const
{
    torch::Tensor s = torch::linspace(0.00, m_physics_params.L[0UL] + tau[0UL], Nodes, torch::kFloat64).unsqueeze(1);
    torch::Tensor tau_row = get_input_tensor(tau);
    torch::Tensor tau_cols = tau_row.repeat({Nodes, 1});
    torch::Tensor input = torch::cat({s, tau_cols}, 1);

    torch::NoGradGuard no_grad_guard;
    torch::Tensor states_torch = m_dnn->forward({input}).toTensor();
    torch::Tensor shape_torch = states_torch.index({torch::indexing::Slice(), torch::indexing::Slice(8, 11)}).contiguous();

    // Access tensor data as 2D array [Nodes x 3]
    auto accessor = shape_torch.accessor<double, 2>();

    // Copy column by column to respect Blaze’s column-major layout
    for (size_t j = 0; j < 3; ++j)
        for (size_t i = 0; i < Nodes; ++i)
            shape(i, j) = accessor[i][j];
}

// // method for computing the Pseudoinverse of a matrix
template <size_t Nodes, size_t controlInputs>
blaze::StaticMatrix<double, 6UL, 3UL, blaze::columnMajor>
PINNs<Nodes, controlInputs>::pInv(const blaze::StaticMatrix<double, 3UL, 6UL, blaze::columnMajor> &M)
{
    // M+ = M^T(MM^T+λI)⁻¹
    static constexpr double lambda = 1.00E-12; // small damping factor (Tikhonov regularization)

    constexpr blaze::IdentityMatrix<double> I(3UL);

    // Compute: A = M * trans(M) + λI  (A is 3x3)
    const blaze::StaticMatrix<double, 3UL, 3UL, blaze::columnMajor> A = (M * blaze::trans(M)) + lambda * I;

    // Add damping to the diagonal
    // blaze::diagonal(A) += lambda;
    // A(i, i) += lambda;
    blaze::StaticMatrix<double, 3UL, 3UL, blaze::columnMajor> A_inv;

    try
    {
        // Compute the inverse of A (3x3)
        A_inv = blaze::inv(A);
    }
    catch (const std::exception &e)
    {
        std::cerr << "Matrix inversion failed: " << e.what() << std::endl;
        return blaze::StaticMatrix<double, 6UL, 3UL, blaze::columnMajor>(0.00);
    }

    // Compute pseudoinverse: M⁺ = trans(M) * A⁻¹   (6x3 result)
    return blaze::trans(M) * A_inv;
}

#endif