#pragma once

#include <ompl/base/StateSampler.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/ScopedState.h>
#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/StateSampler.h>

#include <memory>
#include <cmath>

#include "PINNs.hpp"
#include "CTR_StateValidityChecker.hpp"

// A simple PINNs-informed state sampler that biases samples toward the goal
// tip position. This is NOT an OMPL InformedStateSampler subclass; instead it
// implements ompl::base::StateSampler and can be installed via
// setStateSamplerAllocator on the state space. It uses the PINNs forward model
// to compute tip positions and the PINNs::posCTRL (IK) routine to map a
// target tip back to a joint configuration. If IK or validity checks fail the
// sampler falls back to the provided uniform sampler.

template <size_t Nodes, size_t controlInputs>
class CTR_PINNsInformedSampler : public ompl::base::StateSampler
{
public:
    // ctor: space must outlive this sampler. fallbackSampler is used when the
    // informed approach fails; it can be the regular CTR_StateSampler.
    CTR_PINNsInformedSampler(const ompl::base::StateSpace *space,
                             CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker,
                             PINNs<Nodes, controlInputs> &ctr,
                             ompl::base::StateSamplerPtr fallbackSampler)
        : ompl::base::StateSampler(space), m_validityChecker(validityChecker), m_ctr(ctr), m_fallback(std::move(fallbackSampler))
    {
        // default bias: how often to attempt an informed sample [0..1]
        m_bias = 0.50;
        // default radius (meters) around goal tip used for sampling tip-space
        m_tipRadius = 0.01; // 1 cm by default; tune for your workspace
    }

    ~CTR_PINNsInformedSampler() override = default;

    // Set the desired bias (probability of generating informed samples)
    void setBias(double b) { m_bias = std::min(std::max(b, 0.00), 1.00); }

    // Set the tip-space sampling radius in meters
    void setTipRadius(double r) { m_tipRadius = std::max(r, 0.00); }

    // Set maximum informed attempts when trying IK-based samples
    void setMaxAttempts(int n) { m_maxAttempts = std::max(1, n); }

    // Provide the goal state so the sampler can compute goal tip position
    void setGoalState(const ompl::base::State *goal)
    {
        if (!goal)
        {
            m_hasGoal = false;
            return;
        }
        m_hasGoal = true;
        const auto *rv = goal->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            m_goalVec[i] = rv->values[i];
        // compute tip position for goal using PINNs
        try
        {
            m_ctr.get_pos_distal(m_goalVec, m_goalTip);
        }
        catch (...) // be conservative
        {
            m_hasGoal = false;
        }
    }

    // Primary sampling method called by OMPL
    void sampleUniform(ompl::base::State *state) override
    {
        // With probability m_bias attempt an informed sample; otherwise fallback
        const double u = rng_.uniformReal(0.00, 1.00);
        if (u > m_bias || !m_hasGoal)
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }

        // Attempt informed sample in tip-space with multiple tries: pick a random point within
        // a ball of radius m_tipRadius centered at the goal tip, then try to
        // solve IK (posCTRL) to obtain a joint configuration that reaches it.
        bool success = false;
        blaze::StaticVector<double, controlInputs> tauInit;
        for (int attempt = 0; attempt < m_maxAttempts; ++attempt)
        {
            blaze::StaticVector<double, 3UL> tipSample;
            randomPointInBall(m_goalTip, m_tipRadius, tipSample);

            tauInit = m_goalVec; // start from goal as initial guess
            try
            {
                m_ctr.posCTRL(tauInit, tipSample, 1.00E-3);
                success = true;
                break;
            }
            catch (...)
            {
                // try again
            }
        }

        if (!success)
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }

        // Build OMPL state from tauInit
        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            rv->values[i] = tauInit[i];

        // If state is invalid, fall back
        if (!m_validityChecker.isValid(state))
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }
    }

    void sampleUniformNear(ompl::base::State *state, const ompl::base::State *near, double distance) override
    {
        // Try a small perturbation around `near`; favor moving tip toward goal
        auto *qnear = near->as<ompl::base::RealVectorStateSpace::StateType>();
        blaze::StaticVector<double, controlInputs> q;
        for (size_t i = 0; i < controlInputs; ++i)
            q[i] = qnear->values[i];

        // perturb prismatic joints within distance and keep ordering
        for (size_t i = 0; i < 3; ++i)
            q[i] += rng_.uniformReal(-distance, distance);
        // re-sort to enforce beta1 < beta2 < beta3
        sort3(q[0], q[1], q[2]);
        // perturb revolute joints
        for (size_t i = 3; i < controlInputs; ++i)
            q[i] = std::fmod(q[i] + rng_.uniformReal(-distance, distance), 2.00 * M_PI);

        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            rv->values[i] = q[i];

        if (!m_validityChecker.isValid(state) && m_fallback)
            m_fallback->sampleUniformNear(state, near, distance);
    }

    void sampleGaussian(ompl::base::State *state, const ompl::base::State *mean, double stdDev) override
    {
        // Gaussian around mean, then try to bias toward goal via a single
        // informed attempt: if random < m_bias and we have goal try small IK
        auto *qmean = mean->as<ompl::base::RealVectorStateSpace::StateType>();
        blaze::StaticVector<double, controlInputs> q;
        for (size_t i = 0; i < controlInputs; ++i)
            q[i] = qmean->values[i] + rng_.gaussian(0.00, stdDev);

        // clamp/wrap and enforce ordering
        sort3(q[0], q[1], q[2]);
        for (size_t i = 3; i < controlInputs; ++i)
        {
            q[i] = std::fmod(q[i], 2.00 * M_PI);
            if (q[i] < 0.00)
                q[i] += 2.00 * M_PI;
        }

        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            rv->values[i] = q[i];

        if (!m_validityChecker.isValid(state) && m_fallback)
            m_fallback->sampleGaussian(state, mean, stdDev);
    }

private:
    CTR_StateValidityChecker<Nodes, controlInputs> &m_validityChecker;
    PINNs<Nodes, controlInputs> &m_ctr;
    ompl::RNG rng_;
    ompl::base::StateSamplerPtr m_fallback;

    // goal info
    bool m_hasGoal{false};
    blaze::StaticVector<double, controlInputs> m_goalVec{};
    blaze::StaticVector<double, 3UL> m_goalTip{};

    double m_bias;      // probability to attempt informed sample
    double m_tipRadius; // meters
    int m_maxAttempts{10};

    // Helpers
    void randomPointInBall(const blaze::StaticVector<double, 3UL> &center, double radius, blaze::StaticVector<double, 3UL> &out)
    {
        // uniform in ball via rejection in cube (simple and fine for small dims)
        for (int attempts = 0; attempts < 20; ++attempts)
        {
            const double rx = rng_.uniformReal(-radius, radius);
            const double ry = rng_.uniformReal(-radius, radius);
            const double rz = rng_.uniformReal(-radius, radius);
            if (rx * rx + ry * ry + rz * rz <= radius * radius)
            {
                out[0] = center[0] + rx;
                out[1] = center[1] + ry;
                out[2] = center[2] + rz;
                return;
            }
        }
        // fallback: return center
        out = center;
    }

    static void sort3(double &a, double &b, double &c)
    {
        if (a > b)
            std::swap(a, b);
        if (b > c)
            std::swap(b, c);
        if (a > b)
            std::swap(a, b);
    }
};
