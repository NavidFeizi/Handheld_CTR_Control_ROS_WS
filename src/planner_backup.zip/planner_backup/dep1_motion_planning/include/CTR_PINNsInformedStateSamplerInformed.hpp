#pragma once

#include <ompl/base/samplers/InformedStateSampler.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/StateSampler.h>
#include <ompl/base/ScopedState.h>
#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/OptimizationObjective.h>

#include <memory>
#include <cmath>
#include <functional>

#include "PINNs.hpp"
#include "CTR_StateValidityChecker.hpp"

// An OMPL InformedStateSampler wrapper that uses the PINNs forward/IK model
// to directly sample states inside the admissible cost set for objectives
// that otherwise would fall back to rejection sampling. This implementation
// uses a conservative, state-space admissible lower-bound test (euclidean
// + angular differences) to decide admissibility relative to the provided
// bestCost. If an informed sample cannot be produced within a bounded
// number of attempts, the sampler falls back to a provided uniform sampler.

// Notes:
// - This class intentionally keeps the admissibility test conservative
//   (replicates the simple state-space distance heuristic) so it does not
//   introduce optimistic (inadmissible) heuristics that could invalidate
//   planner correctness.
// - The class is templated over the PINNs sizes to match the rest of the
//   project.

template <size_t Nodes, size_t controlInputs>
class CTR_PINNsInformedStateSampler : public ompl::base::InformedStateSampler
{
public:
    // Construct with ProblemDefinition and a get-cost function compatible
    // with OMPL's InformedStateSampler. maxNumberCalls selects an internal
    // budget for attempts and is forwarded to the base class.
    CTR_PINNsInformedStateSampler(const ompl::base::ProblemDefinitionPtr &probDefn,
                                  const std::function<ompl::base::Cost()> &getCostFunc,
                                  CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker,
                                  PINNs<Nodes, controlInputs> &ctr,
                                  ompl::base::StateSamplerPtr fallback,
                                  unsigned int maxNumberCalls = 1000)
        : ompl::base::InformedStateSampler(probDefn, maxNumberCalls, getCostFunc), m_getCostFunc(getCostFunc), m_validityChecker(validityChecker), m_ctr(ctr), m_fallback(std::move(fallback))
    {
        m_bias = 0.5;       // placeholder
        m_tipRadius = 0.02; // meters
        m_hasGoal = false;
    }

    // Alternate constructor: accept an explicit InformedSampler instance
    // and forward it to the base InformedStateSampler constructor. This
    // allows bypassing OMPL's default allocation path and prevents the
    // library from falling back to rejection sampling when a component
    // objective provides a direct InformedSampler.
    CTR_PINNsInformedStateSampler(const ompl::base::ProblemDefinitionPtr &probDefn,
                                  const std::function<ompl::base::Cost()> &getCostFunc,
                                  const ompl::base::InformedSamplerPtr &informedSampler,
                                  CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker,
                                  PINNs<Nodes, controlInputs> &ctr,
                                  ompl::base::StateSamplerPtr fallback)
        : ompl::base::InformedStateSampler(probDefn, getCostFunc, informedSampler), m_getCostFunc(getCostFunc), m_validityChecker(validityChecker), m_ctr(ctr), m_fallback(std::move(fallback))
    {
        m_bias = 0.5;
        m_tipRadius = 0.02;
        m_hasGoal = false;
    }

    ~CTR_PINNsInformedStateSampler() override = default;

    // Override cost-bounded sampling so OMPL can use a direct informed
    // sampling scheme instead of falling back to rejection sampling.
    void sampleUniform(ompl::base::State *state, const ompl::base::Cost &minCost, const ompl::base::Cost &maxCost)
    {
        // If we don't have a goal or a valid fallback, use fallback directly
        if (!m_hasGoal || !m_fallback)
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }

        for (int attempt = 0; attempt < m_maxAttempts; ++attempt)
        {
            blaze::StaticVector<double, 3UL> tipSample;
            randomPointInBall(m_goalTip, m_tipRadius, tipSample);

            blaze::StaticVector<double, controlInputs> qInit = m_goalVec;
            try
            {
                m_ctr.posCTRL(qInit, tipSample, 1.00E-3);
            }
            catch (...)
            {
                continue;
            }

            auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
            for (size_t i = 0; i < controlInputs; ++i)
                rv->values[i] = qInit[i];

            if (!m_validityChecker.isValid(state))
                continue;

            double ctg = conservativeCostToGoal(state, m_goalState);
            if (ctg <= maxCost.value() && ctg >= minCost.value())
            {
                return;
            }
        }

        // Fallback to uniform sampler if nothing admissible was found
        if (m_fallback)
            m_fallback->sampleUniform(state);
    }

    // Provide the goal state (the raw State pointer). Planner should call
    // this when goal is known so we can compute the goal tip via PINNs.
    void setGoalState(const ompl::base::State *goal)
    {
        if (!goal)
        {
            m_hasGoal = false;
            return;
        }
        m_hasGoal = true;
        const auto *rv = goal->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            m_goalVec[i] = rv->values[i];
        try
        {
            m_ctr.get_pos_distal(m_goalVec, m_goalTip);
        }
        catch (...) // be conservative
        {
            m_hasGoal = false;
        }
        m_goalState = goal;
    }

    // Set radius (meters) used when sampling in tip-space
    void setTipRadius(double r) { m_tipRadius = std::max(0.0, r); }

    // OMPL calls this to request a sample inside the admissible set. We
    // retrieve the current best cost via the provided get-cost function and
    // attempt several informed samples (PINNs IK). If none satisfy the
    // conservative admissibility test we fall back to the uniform sampler.
    void sampleUniform(ompl::base::State *state) override
    {
        const ompl::base::Cost bestCost = m_getCostFunc ? m_getCostFunc() : ompl::base::Cost(std::numeric_limits<double>::infinity());

        // If we don't have a goal or a valid fallback, use fallback directly
        if (!m_hasGoal || !m_fallback)
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }

        for (int attempt = 0; attempt < m_maxAttempts; ++attempt)
        {
            blaze::StaticVector<double, 3UL> tipSample;
            randomPointInBall(m_goalTip, m_tipRadius, tipSample);

            blaze::StaticVector<double, controlInputs> qInit = m_goalVec;
            try
            {
                m_ctr.posCTRL(qInit, tipSample, 1.00E-3);
            }
            catch (...)
            {
                continue;
            }

            auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
            for (size_t i = 0; i < controlInputs; ++i)
                rv->values[i] = qInit[i];

            if (!m_validityChecker.isValid(state))
                continue;

            double ctg = conservativeCostToGoal(state, m_goalState);
            if (ctg <= bestCost.value())
            {
                return;
            }
        }

        m_fallback->sampleUniform(state);
    }

    // Allow runtime tuning of the maximum number of informed attempts
    void setMaxAttempts(int n) { m_maxAttempts = std::max(1, n); }

    // Fallback implementations: delegate to fallback sampler to keep behavior
    void sampleUniformNear(ompl::base::State *state, const ompl::base::State *near, double distance) override
    {
        if (m_fallback)
            m_fallback->sampleUniformNear(state, near, distance);
        else
            ompl::RNG().uniformReal(0.0, 1.0); // no-op
    }

    void sampleGaussian(ompl::base::State *state, const ompl::base::State *mean, double stdDev) override
    {
        if (m_fallback)
            m_fallback->sampleGaussian(state, mean, stdDev);
    }

private:
    std::function<ompl::base::Cost()> m_getCostFunc;
    CTR_StateValidityChecker<Nodes, controlInputs> &m_validityChecker;
    PINNs<Nodes, controlInputs> &m_ctr;
    ompl::base::StateSamplerPtr m_fallback;
    ompl::RNG rng_;
    int m_maxAttempts{50};

    // No debug prints in sampler to avoid console flooding.

    // goal info
    bool m_hasGoal{false};
    const ompl::base::State *m_goalState{nullptr};
    blaze::StaticVector<double, controlInputs> m_goalVec{};
    blaze::StaticVector<double, 3UL> m_goalTip{};

    double m_bias;      // unused placeholder
    double m_tipRadius; // meters

    // Helpers: draw a uniform point inside a 3D ball
    void randomPointInBall(const blaze::StaticVector<double, 3UL> &center, double radius, blaze::StaticVector<double, 3UL> &out)
    {
        for (int attempts = 0; attempts < 30; ++attempts)
        {
            const double rx = rng_.uniformReal(-radius, radius);
            const double ry = rng_.uniformReal(-radius, radius);
            const double rz = rng_.uniformReal(-radius, radius);
            if (rx * rx + ry * ry + rz * rz <= radius * radius)
            {
                out[0] = center[0] + rx;
                out[1] = center[1] + ry;
                out[2] = center[2] + rz;
                return;
            }
        }
        out = center;
    }

    // Conservative state-space cost-to-go used for admissibility checks.
    // Mirrors the simple Cartesian + angular distance heuristic used elsewhere
    // in the codebase (prismatic indices 0..2, revolute 3..5).
    double conservativeCostToGoal(const ompl::base::State *s, const ompl::base::State *g) const
    {
        if (!s || !g)
            return std::numeric_limits<double>::infinity();
        const auto *xs = s->as<ompl::base::RealVectorStateSpace::StateType>();
        const auto *xg = g->as<ompl::base::RealVectorStateSpace::StateType>();
        double sum = 0.0;
        for (std::size_t i = 0; i < 3; ++i)
        {
            const double d = xs->values[i] - xg->values[i];
            sum += d * d;
        }
        for (std::size_t i = 3; i < 6; ++i)
        {
            double d = xs->values[i] - xg->values[i];
            while (d > M_PI)
                d -= 2.0 * M_PI;
            while (d < -M_PI)
                d += 2.0 * M_PI;
            sum += d * d;
        }
        return std::sqrt(sum);
    }

    // Inform OMPL that we can provide a (non-zero) informed measure and a
    // simple estimate for it. Returning a positive measure allows OMPL to
    // use direct informed-sampling pathways instead of rejection sampling.
    bool hasInformedMeasure() const { return true; }

    // Provide a conservative (positive) estimate of the informed measure.
    // We use the tip-space sampling radius volume as a cheap proxy. OMPL
    // only needs a positive value to avoid rejecting the direct sampling
    // path; exactness is not required here.
    double getInformedMeasure(const ompl::base::Cost & /*currentCost*/) const
    {
        if (!m_hasGoal)
            return 0.0;
        const double r = std::max(0.0, m_tipRadius);
        // Volume of a 3D ball
        const double vol = (4.0 / 3.0) * M_PI * r * r * r;
        return vol;
    }
};
