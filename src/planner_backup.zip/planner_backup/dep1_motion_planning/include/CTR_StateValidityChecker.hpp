#pragma once

#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/SpaceInformation.h>
#include <ompl/base/StateValidityChecker.h>
#include <ompl/base/MotionValidator.h>

// including the CTR class to compute illegal configurations and collisions with the anatomy
#include "PINNs.hpp"
#include <iostream>

// Make CTR_StateSampler templated to match PINNs
template<size_t Nodes, size_t controlInputs>
class CTR_StateValidityChecker : public ompl::base::StateValidityChecker
{
public:
    CTR_StateValidityChecker() = delete;

    CTR_StateValidityChecker(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs>& _ctr);

    bool isValid(const ompl::base::State *state) const override;

    double clearance(const ompl::base::State* state) const override;

    // New methods to set/get the final/goal betas
    void setGoalBetas(double beta1, double beta2, double beta3);

    double getBeta1Goal() const;
    
    double getBeta2Goal() const;
    
    double getBeta3Goal() const;

private:
    double m_Clr; // clearance radius
    blaze::StaticVector<double, controlInputs> m_prismaticRanges, m_revoluteRanges;
    double m_beta1_goal, m_beta2_goal, m_beta3_goal;
};

// ============================= Implementation =============================

template<size_t Nodes, size_t controlInputs>
CTR_StateValidityChecker<Nodes, controlInputs>::CTR_StateValidityChecker(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs>& _ctr) : ompl::base::StateValidityChecker(si) 
{
    this->m_prismaticRanges = _ctr.getPrismaticJointRanges();
    this->m_revoluteRanges = _ctr.getRevoluteJointRanges();
    this->m_Clr = _ctr.getStageThickness();
}

template<size_t Nodes, size_t controlInputs>
bool CTR_StateValidityChecker<Nodes, controlInputs>::isValid(const ompl::base::State *state) const
{
    // std::cout << "CTR_StateValidityChecker called!" << std::endl;
    bool validState = true;
    const ompl::base::RealVectorStateSpace::StateType *candidate_State = state->as<ompl::base::RealVectorStateSpace::StateType>();

    // retrieving the joint values of the linear actuators
    const double beta_1 = candidate_State->values[0UL];
    const double beta_2 = candidate_State->values[1UL];
    const double beta_3 = candidate_State->values[2UL];
    
    // >> checking for illegal configurations of the robot (linear actuator constraints)

    // (beta_1 >= beta_1_min) AND (beta_1 <= MIN(beta_1_max, beta_2 - clr)
    const bool conditionTb1 = ((beta_1 >= m_prismaticRanges[0UL]) && (beta_1 <= std::min(m_prismaticRanges[1UL], beta_2 - m_Clr)) ) ? true : false;

    // (beta_2 >= MAX(beta_1 + clr, beta_2_min)) AND (beta_2 <= MIN(beta_2_max, beta_3 - clr)
    const bool conditionTb2 = ((beta_2 >= std::max(beta_1 + m_Clr, m_prismaticRanges[2UL])) && (beta_2 <= std::min(m_prismaticRanges[3UL], beta_3 - m_Clr)) ) ? true : false;

    // (beta_3 >= MAX(beta_2 + clr, beta_3_min)) AND (beta_3 <= beta_3_max
    const bool conditionTb3 = ((beta_3 >= std::max(beta_2 + m_Clr, m_prismaticRanges[4UL])) && (beta_3 <= m_prismaticRanges[5UL]) ) ? true : false;

    /*
    Accounting for the constraint on the relative angles of the revolute joints between the inner and intermediate tube:
    alpha_1 >= alpha_2 - π AND alpha_1 <= alpha_2 + π
    */
    // retrieving the revolute joint values for the inner and intermediate tube
    const double alpha_1 = candidate_State->values[3UL];
    const double alpha_2 = candidate_State->values[4UL];

    bool revoluteCondition = std::fabs(alpha_1 - alpha_2) <= M_PI ? true : false;

    // If the sampled state results in illegal configuration of the CTR, reject it!
    if (!(conditionTb1 && conditionTb2 && conditionTb3 && revoluteCondition))
    {
        // std::cout << "Drawed actuation values outside the allowable range!" << std::endl;
        validState = false;
    }    

    // returns the result of the validity check
    return validState; // Replace with collision check result
}

// function that computes the clearance (minimum distance) between the CTR and the anatomy
template<size_t Nodes, size_t controlInputs>
double CTR_StateValidityChecker<Nodes, controlInputs>::clearance(const ompl::base::State* state) const
{
    // return this->ctr->computeAnatomicalDistances();
    return 0.05;
}

template<size_t Nodes, size_t controlInputs>
void CTR_StateValidityChecker<Nodes, controlInputs>::setGoalBetas(double beta1, double beta2, double beta3)
{
    m_beta1_goal = beta1;
    m_beta2_goal = beta2;
    m_beta3_goal = beta3;
}

template<size_t Nodes, size_t controlInputs>
double CTR_StateValidityChecker<Nodes, controlInputs>::getBeta1Goal() const { return m_beta1_goal; }

template<size_t Nodes, size_t controlInputs>
double CTR_StateValidityChecker<Nodes, controlInputs>::getBeta2Goal() const { return m_beta2_goal; }

template<size_t Nodes, size_t controlInputs>
double CTR_StateValidityChecker<Nodes, controlInputs>::getBeta3Goal() const { return m_beta3_goal; }