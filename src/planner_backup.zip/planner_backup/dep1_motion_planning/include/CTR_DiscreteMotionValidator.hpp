// Discrete motion validator for CTR: checks interpolated states along an edge
// for mechanical ordering constraints (beta sequence) and (future) anatomical
// collisions. Uses SpaceInformation's state allocation utilities and reuses a
// single temporary state for efficiency.

#pragma once

#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/SpaceInformation.h>
#include <ompl/base/StateValidityChecker.h>
#include <ompl/base/DiscreteMotionValidator.h>
#include <cmath>
#include <algorithm>
#include <limits>
#include "PINNs.hpp"

template <size_t Nodes, size_t controlInputs>
class CTR_DiscreteMotionValidator : public ompl::base::DiscreteMotionValidator
{
public:
    CTR_DiscreteMotionValidator(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs> &_ctr);

    // Basic motion check (OMPL will call the 3-arg variant optionally); we
    // override the 2-arg and let the base class handle lastValid bookkeeping.
    bool checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const override;

    void setGoalBetas(double b1, double b2, double b3);

private:
    PINNs<Nodes, controlInputs> &m_ctr;
    double m_Clr{0.0}; // clearance radius between prismatic segments
    double beta1_goal{0.0}, beta2_goal{0.0}, beta3_goal{0.0};
    mutable bool goalBetasSet{false};
    static constexpr double goalTolerance{1.00E-6}; // tolerance for goal comparison
};

// ============================= Implementation =============================

template <size_t Nodes, size_t controlInputs>
CTR_DiscreteMotionValidator<Nodes, controlInputs>::CTR_DiscreteMotionValidator(const ompl::base::SpaceInformationPtr &si, PINNs<Nodes, controlInputs> &_ctr)
    : ompl::base::DiscreteMotionValidator(si), m_ctr(_ctr)
{
    m_Clr = _ctr.getStageThickness();
}

template <size_t Nodes, size_t controlInputs>
bool CTR_DiscreteMotionValidator<Nodes, controlInputs>::checkMotion(const ompl::base::State *s1, const ompl::base::State *s2) const
{
    // Require goal betas to be set (used for deployment-phase constraints)
    if (!goalBetasSet)
        return false;

    // Quick validity of endpoints
    if (!si_->isValid(s1) || !si_->isValid(s2))
        return false;

    // If identical states, treat as valid (already checked)
    if (si_->getStateSpace()->equalStates(s1, s2))
        return true;

    // Number of interpolation samples excluding endpoints (t in (0,1))
    static constexpr std::size_t numSamples = 4; // adjustable: more samples => finer checking

    // Reusable temporary state
    auto *tmp = si_->getStateSpace()->allocState();

    // Track whether a tube has reached its goal (within tolerance)
    bool beta3Reached = false;
    bool beta2Reached = false;

    // Extract initial betas for sequence enforcement
    const auto *rv1 = s1->as<ompl::base::RealVectorStateSpace::StateType>();
    const auto *rv2 = s2->as<ompl::base::RealVectorStateSpace::StateType>();

    for (std::size_t i = 1; i <= numSamples; ++i)
    {
        double t = static_cast<double>(i) / static_cast<double>(numSamples + 1); // avoids endpoints
        si_->getStateSpace()->interpolate(s1, s2, t, tmp);

        const auto *rv = tmp->as<ompl::base::RealVectorStateSpace::StateType>();
        const double b1 = rv->values[0UL];
        const double b2 = rv->values[1UL];
        const double b3 = rv->values[2UL];
        const double alpha1 = rv->values[3UL];
        const double alpha2 = rv->values[4UL];

        // Mechanical ordering constraints with clearance
        if (b1 > b2 - m_Clr || b2 > b3 - m_Clr)
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }

        // Enforce revolute joint proximity: |alpha1 - alpha2| <= pi
        if (std::fabs(alpha1 - alpha2) > M_PI)
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }

        // Deployment-phase constraint: once a tube reaches its goal length we
        // forbid it from retracting (monotonic non-decreasing toward goal).
        // Use small tolerance for floating comparisons.
        if (!beta3Reached && std::fabs(b3 - beta3_goal) <= goalTolerance)
            beta3Reached = true;
        if (beta3Reached && b3 < beta3_goal - goalTolerance)
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }

        if (!beta2Reached && std::fabs(b2 - beta2_goal) <= goalTolerance)
            beta2Reached = true;
        if (beta2Reached && b2 < beta2_goal - goalTolerance)
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }

        // State validity checker may include additional constraints (e.g. collisions)
        if (!si_->isValid(tmp))
        {
            si_->getStateSpace()->freeState(tmp);
            return false;
        }
    }

    si_->getStateSpace()->freeState(tmp);
    return true;
}

template <size_t Nodes, size_t controlInputs>
void CTR_DiscreteMotionValidator<Nodes, controlInputs>::setGoalBetas(double b1, double b2, double b3)
{
    beta1_goal = b1;
    beta2_goal = b2;
    beta3_goal = b3;
    goalBetasSet = true;
}