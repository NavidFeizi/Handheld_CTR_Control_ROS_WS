#pragma once

#include <ompl/base/SpaceInformation.h>
#include <ompl/base/PlannerStatus.h>
#include <ompl/base/StateValidityChecker.h>
#include <ompl/base/objectives/PathLengthOptimizationObjective.h>
#include <ompl/base/objectives/StateCostIntegralObjective.h>
#include <ompl/base/objectives/MaximizeMinClearanceObjective.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>

// The supported optimal planners, in alphabetical order
#include <ompl/geometric/planners/informedtrees/AITstar.h>
#include <ompl/geometric/planners/informedtrees/BITstar.h>
#include <ompl/geometric/planners/cforest/CForest.h>
#include <ompl/geometric/planners/fmt/FMT.h>

// NEW PLANNERS THAT I'M INCLUDING NOW
#include <ompl/geometric/planners/prm/PRM.h>
#include <ompl/geometric/planners/prm/SPARS.h>
#include <ompl/geometric/planners/rrt/RRT.h>
#include <ompl/geometric/planners/rrt/RRTConnect.h>
#include <ompl/geometric/planners/rrt/RRTsharp.h>
#include <ompl/geometric/planners/rlrt/RLRT.h>

#include <ompl/geometric/planners/fmt/BFMT.h>
#include <ompl/geometric/planners/prm/PRMstar.h>
#include <ompl/geometric/planners/rrt/InformedRRTstar.h>
#include <ompl/geometric/planners/rrt/RRTstar.h>
#include <ompl/geometric/planners/rrt/SORRTstar.h>

// For boost program options
#include <boost/program_options.hpp>
// For string comparison (boost::iequals)
#include <boost/algorithm/string.hpp>
// For std::make_shared
#include <memory>
// For handling/writing/reading files
#include <fstream>
#include <thread>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <array>
#include <algorithm>
#include <blaze/Math.h>
#include <cmath>
#include <filesystem>
#include <ompl/base/goals/GoalState.h>
#include <ompl/base/goals/GoalStates.h>
// For accessing information about the CTR object for whom we're planning
#include "PINNs.hpp"

// My own classes that I implemented
#include "CTR_StateSampler.hpp"
#include "CTR_StateValidityChecker.hpp"
#include "CTR_RevoluteJointObjective.hpp"
#include "CTR_BackboneLengthObjective.hpp"
#include "CTR_ClearanceObjective.hpp"
#include "CTR_DiscreteMotionValidator.hpp"
#include "CTR_PINNsInformedSampler.hpp"
#include "CTR_PINNsInformedStateSamplerInformed.hpp"
#include "InformedSamplerGuard.hpp"
#include "Logging.hpp"

// Helper: wrap angular difference to [-pi, pi]
static inline double shortestAngleDiff(double a, double b)
{
	double d = a - b;
	while (d > M_PI)
		d -= 2.00 * M_PI;
	while (d < -M_PI)
		d += 2.00 * M_PI;
	return d;
}

// Centralized composite parameters shared between objective and diagnostics
struct CompositeParams
{
	static constexpr double w_backbone = 3.00;
	static constexpr double w_revolute = 15.00;
	static constexpr double k_coupling = 1.50;
	static constexpr double w_mismatch = 225.00;
	static constexpr double k_frontload = 1.75;
	static constexpr double tau_frontload = 0.18;
	static constexpr double p_front_gate = 0.35;
	static constexpr double angle_front_gate_thresh = 0.30;
	static constexpr double w_front_gate = 200.0;
	static constexpr double p_gate = 0.25;
	static constexpr double angle_gate_thresh = 0.0175; // ~1 degree
	static constexpr double w_gate = 200.0;
	static constexpr double w_progress_lag = 400000.0;
	static constexpr double lag_slack = 0.005;
	static constexpr double lag_power = 2.0;
};

// Close any remaining open scope introduced by local classes/lambdas above.
// (Balancing brace added to fix a missing closing brace introduced during edits.)

// Cost-to-go heuristic suitable for state-space path-length optimization.
// Assumes states are RealVectorStateSpace states and indices:
//  0..2 -> prismatic (linear), 3..5 -> revolute (angles)
static inline ompl::base::Cost ctrStateSpaceCostToGo(const ompl::base::State *s1, const ompl::base::State *s2)
{
	using StateType = ompl::base::RealVectorStateSpace::StateType;
	auto *x = s1->as<StateType>();
	auto *y = s2->as<StateType>();
	if (!x || !y)
		return ompl::base::Cost(0.00);

	double sum = 0.00;
	// prismatic indices (0,1,2)
	for (std::size_t i = 0; i < 3; ++i)
	{
		const double d = x->values[i] - y->values[i];
		sum += d * d;
	}
	// revolute indices (3,4,5)
	for (std::size_t i = 3; i < 6; ++i)
	{
		const double d = shortestAngleDiff(x->values[i], y->values[i]);
		sum += d * d;
	}
	return ompl::base::Cost(std::sqrt(sum));
}

// Cost-to-go adapter that matches OMPL's CostToGoHeuristic signature:
// Cost(const State*, const Goal*)
static inline ompl::base::Cost ctrCostToGoal(const ompl::base::State *state, const ompl::base::Goal *goal)
{
	using namespace ompl::base;

	if (!goal)
		return Cost(0.00);

	// If the goal is a single state, use that state directly
	if (goal->hasType(GoalType::GOAL_STATE))
	{
		const GoalState *gs = goal->as<GoalState>();
		const State *gstate = gs->getState();
		if (!gstate)
			return Cost(0.00);
		return ctrStateSpaceCostToGo(state, gstate);
	}

	// If the goal is a set of states, return the minimum cost-to-go to any of them
	if (goal->hasType(GoalType::GOAL_STATES))
	{
		const GoalStates *gss = goal->as<GoalStates>();
		std::size_t count = gss->getStateCount();
		if (count == 0)
			return Cost(0.00);
		double best = std::numeric_limits<double>::infinity();
		for (std::size_t i = 0; i < count; ++i)
		{
			const State *gs = gss->getState(i);
			if (!gs)
				continue;
			double val = ctrStateSpaceCostToGo(state, gs).value();
			if (val < best)
				best = val;
		}
		return Cost(best == std::numeric_limits<double>::infinity() ? 0.00 : best);
	}

	return Cost(0.00);
}

template <std::size_t Nodes, std::size_t controlInputs>
class Planner
{
public:
	using JointVector = blaze::StaticVector<double, controlInputs>;

	enum class optimalPlanner
	{
		PLANNER_AITSTAR,
		PLANNER_BFMTSTAR,
		PLANNER_BITSTAR,
		PLANNER_CFOREST,
		PLANNER_FMTSTAR,
		PLANNER_INF_RRTSTAR,
		PLANNER_PRMSTAR,
		PLANNER_RRTSTAR,
		PLANNER_SORRTSTAR,
		PLANNER_PRM,
		PLANNER_SPARS,
		PLANNER_RRT,
		PLANNER_RRT_CONNECT,
		PLANNER_RRT_SHARP,
		PLANNER_RLRT
	};

	enum class planningObjective
	{
		OBJECTIVE_PATH_CLEARANCE,
		OBJECTIVE_PATH_LENGTH,
		OBJECTIVE_REVJOINTS_AND_BACKBONE,
		OBJECTIVE_PATH_LENGTH_COST2GO,
		OBJECTIVE_THRESHOLD_PATH_LENGTH,
		OBJECTIVE_WEIGHTED_COMBO,
		OBJECTIVE_BACKBONE_LENGTH
	};

	explicit Planner(PINNs<Nodes, controlInputs> &CTR_model);

	bool resetStartState(const JointVector &q0);
	bool resetGoalState(const JointVector &qf);
	bool resetStartAndGoalStates(const JointVector &q0, const JointVector &qf);
	bool setStartState(const JointVector &q_0);
	bool setGoalState(const JointVector &q_f);
	int plan(double runTime, optimalPlanner plannerType, planningObjective objectiveType);
	int replan(double runTime);
	void writeSolutionToFile(const std::string &outputFile);
	void analyzeSolution(bool dumpCSV, const std::string &csvPath);
	void cleanup();

	ompl::base::OptimizationObjectivePtr getRevoluteJointObjective(const std::array<double, 3UL> &goal);
	ompl::base::OptimizationObjectivePtr getPathLengthObjective();
	ompl::base::OptimizationObjectivePtr getThresholdPathLengthObjctive();
	ompl::base::OptimizationObjectivePtr getClearanceObjective();
	ompl::base::OptimizationObjectivePtr RevoluteJointsAndBackboneLengthObjective(const std::array<double, 3UL> &goal);
	ompl::base::OptimizationObjectivePtr getBalancedObjective();
	ompl::base::OptimizationObjectivePtr getPathLengthObjWithCostToGo();
	ompl::base::OptimizationObjectivePtr getBackboneLengthObjective();

private:
	ompl::base::PlannerPtr allocatePlanner(optimalPlanner plannerType);
	ompl::base::OptimizationObjectivePtr allocateObjective(planningObjective objectiveType);

	PINNs<Nodes, controlInputs> &m_CTR_model;
	ompl::base::StateSpacePtr m_space;
	std::shared_ptr<ompl::base::RealVectorBounds> m_coordBound;
	ompl::base::SpaceInformationPtr m_si;
	ompl::base::StateValidityCheckerPtr m_stateValidityChecker;
	ompl::base::ProblemDefinitionPtr m_pdef;
	ompl::base::PlannerPtr m_optimizingPlanner;
	ompl::base::PlannerStatus m_solved = ompl::base::PlannerStatus::UNKNOWN;
	std::shared_ptr<ompl::base::ScopedState<>> m_startState;
	std::shared_ptr<ompl::base::ScopedState<>> m_goalState;
	ompl::base::StateSamplerPtr m_informedSampler;
	bool m_constructingInformedSampler = false;
	double m_informedTipRadius = 0.005;
	unsigned int m_informedMaxAttempts = 1000U;
};

template <size_t Nodes, size_t controlInputs>
Planner<Nodes, controlInputs>::Planner(PINNs<Nodes, controlInputs> &CTR_model)
	: m_CTR_model(CTR_model)
{
	const std::size_t dim = controlInputs;
	m_space = std::make_shared<ompl::base::RealVectorStateSpace>(dim);

	m_coordBound = std::make_shared<ompl::base::RealVectorBounds>(dim);

	// ___ setting bounds for the linear joints ___
	const blaze::StaticVector<double, controlInputs> prismaticJointsRange = CTR_model.getPrismaticJointRanges();

	// beta_1
	m_coordBound->setLow(0, prismaticJointsRange[0UL]);
	m_coordBound->setHigh(0, prismaticJointsRange[1UL]);
	// beta_2
	m_coordBound->setLow(1, prismaticJointsRange[2UL]);
	m_coordBound->setHigh(1, prismaticJointsRange[3UL]);
	// beta_3
	m_coordBound->setLow(2, prismaticJointsRange[4UL]);
	m_coordBound->setHigh(2, prismaticJointsRange[5UL]);

	// ___ setting bounds for the revolute joints ___
	const blaze::StaticVector<double, controlInputs> revolureJointsRange = CTR_model.getRevoluteJointRanges();

	// alpha_1
	m_coordBound->setLow(3, revolureJointsRange[0UL]);
	m_coordBound->setHigh(3, revolureJointsRange[1UL]);
	// alpha_2
	m_coordBound->setLow(4, revolureJointsRange[2UL]);
	m_coordBound->setHigh(4, revolureJointsRange[3UL]);
	// alpha_3
	m_coordBound->setLow(5, revolureJointsRange[4UL]);
	m_coordBound->setHigh(5, revolureJointsRange[5UL]);

	// setting the space bounds for the linear (prismatic) CTR joints
	m_space->as<ompl::base::RealVectorStateSpace>()->setBounds(*m_coordBound);

	// Construct a space information instance for this compound state space
	m_si = std::make_shared<ompl::base::SpaceInformation>(m_space);

	// Set the object used to check which states in the space are valid
	m_stateValidityChecker = std::make_shared<CTR_StateValidityChecker<Nodes, controlInputs>>(this->m_si, m_CTR_model);

	// Create the state validity checker with your CTR instance
	m_si->setStateValidityChecker(m_stateValidityChecker);

	// Enable discrete motion validator for edge checking (deployment monotonicity & ordering)
	m_si->setMotionValidator(std::make_shared<CTR_DiscreteMotionValidator<Nodes, controlInputs>>(m_si, m_CTR_model));
	// Defines the largest fraction of the state space a motion segment can cover without intermediate checks.
	// Tuned to ~3 mm given prismatic ranges; adjust via setter if needed.
	m_si->getStateSpace()->setLongestValidSegmentFraction(0.003);

	// Inside Planner constructor: install an allocator that creates a regular
	// CTR_StateSampler (fallback) and wraps it with a PINNs-informed sampler.
	// The informed sampler will attempt IK-based, tip-space biased samples and
	// fall back to the regular sampler when needed. We also keep a reference
	// to the created informed sampler so we can update its goal later.
	this->m_space->setStateSamplerAllocator([this](const ompl::base::StateSpace *space) -> ompl::base::StateSamplerPtr
											{
												auto validityChecker = std::dynamic_pointer_cast<CTR_StateValidityChecker<Nodes, controlInputs>>(m_stateValidityChecker);
												if (!validityChecker)
													throw std::runtime_error("Expected CTR_StateValidityChecker in Planner constructor sampler allocator");
												// Fallback uniform/CTR sampler
												auto fallback = std::make_shared<CTR_StateSampler<Nodes, controlInputs>>(space, *validityChecker, m_CTR_model);

												// Extract parameters from Planner's bounds and validity checker
												const double beta1_min = m_coordBound->low[0UL];
												const double beta2_min = m_coordBound->low[1UL];
												const double beta3_min = m_coordBound->low[2UL];
												const double clearance = m_CTR_model.getStageThickness(); // Or m_stateValidityChecker->clearance()

												// Set parameters on the fallback sampler
												fallback->setParameters(beta1_min, beta2_min, beta3_min, clearance);

												// At constructor time we do NOT yet have a ProblemDefinition
												// (m_pdef is created later in the Planner constructor). OMPL's
												// InformedStateSampler implementations may expect a valid
												// ProblemDefinition during construction/setup and can
												// dereference it, causing a crash. Therefore, install the
												// fallback CTR_StateSampler here and defer creation of the
												// PINNs-backed InformedStateSampler until plan() where the
												// ProblemDefinition is available.

												// Store the fallback so setGoalState can still update it.
												this->m_informedSampler = fallback;

												return fallback; });

	// // Create the motion validator with your CTR instance
	// m_si->setMotionValidator(std::make_shared<CTR_DiscreteMotionValidator<Nodes, controlInputs>>(this->m_si, this->m_CTR_model));

	// // defines the largest fraction of the state space a motion can cover without intermediate collision checks
	// this->m_si->getStateSpace()->setLongestValidSegmentFraction(0.003); // 3 mm

	// setup the space information from the Real state space
	this->m_si->setup();

	// setting up the pointer to the start state
	this->m_startState = std::make_shared<ompl::base::ScopedState<>>(m_space);

	// setting up the pointer to the goal state
	this->m_goalState = std::make_shared<ompl::base::ScopedState<>>(m_space);

	// create an instance of a planning problem
	this->m_pdef = std::make_shared<ompl::base::ProblemDefinition>(this->m_si);
}

template <size_t Nodes, size_t controlInputs>
bool Planner<Nodes, controlInputs>::resetStartState(const blaze::StaticVector<double, controlInputs> &q0)
{
	// Update our internal start‐state storage
	auto *stored = m_startState->get()->as<ompl::base::RealVectorStateSpace::StateType>();

	for (size_t i = 0; i < controlInputs; ++i)
		stored->values[i] = q0[i];

	// Validate start state
	if (!m_stateValidityChecker->isValid(stored))
		throw std::runtime_error("New start state is invalid!");

	// Clear out the old start, add the new one
	m_pdef->clearStartStates();

	// ProblemDefinition copies the provided state; no need to clone
	m_pdef->addStartState(stored);

	// Reset planner’s internal query & paths
	if (m_optimizingPlanner)
	{
		m_optimizingPlanner->clearQuery();
		m_pdef->clearSolutionPaths();
		m_optimizingPlanner->setProblemDefinition(m_pdef);

		// Re‐setup so everything is internally consistent
		if (!m_optimizingPlanner->isSetup())
    		m_optimizingPlanner->setup();
	}

	std::cout << "Start state has been updated!\n";
	return true;
}

template <size_t Nodes, size_t controlInputs>
bool Planner<Nodes, controlInputs>::resetGoalState(const blaze::StaticVector<double, controlInputs> &qf)
{
	if (!m_goalState || !m_goalState->get())
		throw std::runtime_error("resetGoalState() called before a goal state was allocated. Re-run plan() or construct a new Planner after cleanup().");
	if (!m_pdef)
		throw std::runtime_error("resetGoalState() called after the problem definition was cleared. Rebuild the planner before resetting goals.");
	if (!m_stateValidityChecker)
		throw std::runtime_error("resetGoalState() requires an active state validity checker. Did you call cleanup()?");

	auto *stored = m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
	for (size_t i = 0; i < controlInputs; ++i)
		stored->values[i] = qf[i];

	if (!m_stateValidityChecker->isValid(stored))
		throw std::runtime_error("New goal state is invalid!");

	// Replace existing goal with the updated state
	m_pdef->clearGoal();
	m_pdef->setGoalState(stored);

	// Update helpers that rely on the goal betas/alphas
	if (m_si)
	{
		if (auto motionValidator = std::dynamic_pointer_cast<CTR_DiscreteMotionValidator<Nodes, controlInputs>>(m_si->getMotionValidator()))
			motionValidator->setGoalBetas(qf[0UL], qf[1UL], qf[2UL]);
	}

	if (auto validityChecker = std::dynamic_pointer_cast<CTR_StateValidityChecker<Nodes, controlInputs>>(m_si ? m_si->getStateValidityChecker() : ompl::base::StateValidityCheckerPtr()))
		validityChecker->setGoalBetas(qf[0UL], qf[1UL], qf[2UL]);

	if (this->m_informedSampler)
	{
		if (auto ctrSampler = std::dynamic_pointer_cast<CTR_StateSampler<Nodes, controlInputs>>(this->m_informedSampler))
			ctrSampler->setGoalAngles(qf[3UL], qf[4UL], qf[5UL]);

		if (auto inf = std::dynamic_pointer_cast<CTR_PINNsInformedSampler<Nodes, controlInputs>>(this->m_informedSampler))
			inf->setGoalState(m_goalState->get());
		else if (auto inf2 = std::dynamic_pointer_cast<CTR_PINNsInformedStateSampler<Nodes, controlInputs>>(this->m_informedSampler))
			inf2->setGoalState(m_goalState->get());
	}

	if (this->m_optimizingPlanner)
	{
		this->m_optimizingPlanner->clearQuery();
		this->m_pdef->clearSolutionPaths();
		this->m_optimizingPlanner->setProblemDefinition(this->m_pdef);
		if (!m_optimizingPlanner->isSetup())
    		m_optimizingPlanner->setup();
	}

	std::cout << "Goal state has been updated!\n";
	return true;
}

template <size_t Nodes, size_t controlInputs>
bool Planner<Nodes, controlInputs>::resetStartAndGoalStates(const JointVector &q0, const JointVector &qf)
{
	bool startSet = this->resetStartState(q0);
	bool goalSet = this->resetGoalState(qf);
	return startSet && goalSet;
}

template <size_t Nodes, size_t controlInputs>
bool Planner<Nodes, controlInputs>::setStartState(const blaze::StaticVector<double, controlInputs> &q_0)
{
	// setting the start state for the CTR robot
	auto *state = m_startState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
	for (size_t i = 0; i < controlInputs; ++i)
		state->values[i] = q_0[i]; // Simplified assignment loop

	if (m_stateValidityChecker->isValid(state))
	{
		this->m_pdef->clearStartStates();
		// ProblemDefinition copies the provided state; do not clone to avoid leaks
		this->m_pdef->addStartState(state);

		std::cout << "Start state has been updated!" << std::endl;
		return true;
	}
	else
	{
		throw std::runtime_error("Start State is invalid!");
		return false;
	}
}

template <size_t Nodes, size_t controlInputs>
bool Planner<Nodes, controlInputs>::setGoalState(const blaze::StaticVector<double, controlInputs> &q_f)
{
	// setting the start state for the CTR robot
	auto *state = m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
	for (size_t i = 0; i < controlInputs; ++i)
		state->values[i] = q_f[i]; // Simplified assignment

	if (m_stateValidityChecker->isValid(state))
	{
		m_pdef->clearGoal();
		// ProblemDefinition copies the provided state; do not clone to avoid leaks
		m_pdef->setGoalState(state);
		std::cout << "Goal state has been updated!" << std::endl;

		// Cast the motion validator and set goal betas:
		auto motion_validator = std::dynamic_pointer_cast<CTR_DiscreteMotionValidator<Nodes, controlInputs>>(m_si->getMotionValidator());
		// Cast the state sampler validator and set goal betas:
		auto validity_checker = std::dynamic_pointer_cast<CTR_StateValidityChecker<Nodes, controlInputs>>(m_si->getStateValidityChecker());

		if (motion_validator && validity_checker)
		{
			motion_validator->setGoalBetas(q_f[0UL], q_f[1UL], q_f[2UL]);
			validity_checker->setGoalBetas(q_f[0UL], q_f[1UL], q_f[2UL]);
		}

		// Also propagate goal revolute angles to CTR_StateSampler for rotation-focused sampling bias
		if (this->m_informedSampler)
		{
			auto ctrSampler = std::dynamic_pointer_cast<CTR_StateSampler<Nodes, controlInputs>>(this->m_informedSampler);
			if (ctrSampler)
				ctrSampler->setGoalAngles(q_f[3UL], q_f[4UL], q_f[5UL]);
		}

		// If we have created an informed sampler earlier, update its goal so it
		// can compute the goal tip position for informed sampling.
		if (this->m_informedSampler)
		{
			// Try updating both possible informed sampler implementations
			auto inf = std::dynamic_pointer_cast<CTR_PINNsInformedSampler<Nodes, controlInputs>>(this->m_informedSampler);
			if (inf)
			{
				inf->setGoalState(m_goalState->get());
			}
			else
			{
				auto inf2 = std::dynamic_pointer_cast<CTR_PINNsInformedStateSampler<Nodes, controlInputs>>(this->m_informedSampler);
				if (inf2)
				{
					inf2->setGoalState(m_goalState->get());
				}
			}
		}

		// Reinitialize planner internal query/state now that the goal changed
		if (this->m_optimizingPlanner)
		{
			this->m_optimizingPlanner->clearQuery();
			this->m_pdef->clearSolutionPaths();
			this->m_optimizingPlanner->setProblemDefinition(this->m_pdef);
			if (!this->m_optimizingPlanner->isSetup())
				this->m_optimizingPlanner->setup();
		}

		return true;
	}
	else
	{
		throw std::runtime_error("Goal State is invalid!");
		return false;
	}
}

template <size_t Nodes, size_t controlInputs>
int Planner<Nodes, controlInputs>::plan(const double runTime, optimalPlanner plannerType, planningObjective objectiveType)
{
	// Basic sanity: ensure start and goal are present before planning
	if (!this->m_pdef || this->m_pdef->getStartStateCount() == 0 || !this->m_pdef->getGoal())
		throw std::runtime_error("Start or goal not set before calling plan()");

	// Create the optimization objective specified by the objectiveType argument
	this->m_pdef->setOptimizationObjective(this->allocateObjective(objectiveType));

	// Choose whether to enable the informed sampler for this planning run.
	// By default enable informed sampling for planners that benefit from it
	// (RRT*, InformedRRT*, CForest, BIT*, AIT*). For sampling-based planners
	// that do not use informed sampling (PRM, RRT, PRM variants) we fall back
	// to the regular CTR_StateSampler.
	auto useInformed = false;
	switch (plannerType)
	{
	case optimalPlanner::PLANNER_INF_RRTSTAR:
	case optimalPlanner::PLANNER_RRTSTAR:
	case optimalPlanner::PLANNER_SORRTSTAR:
	case optimalPlanner::PLANNER_BITSTAR:
	case optimalPlanner::PLANNER_AITSTAR:
	case optimalPlanner::PLANNER_CFOREST:
		useInformed = true;
		break;
	default:
		break;
	}
	// Ensure the chosen optimization objective actually exposes a cost-to-go
	// heuristic; informed sampling requires a cost-to-go to be available.
	if (useInformed)
	{
		auto opt = this->m_pdef->getOptimizationObjective();
		if (!opt || !opt->hasCostToGoHeuristic())
		{
			useInformed = false;
			std::cout << "Informed sampler disabled: current objective has no cost-to-go heuristic." << std::endl;
		}
	}

	// Re-install a state sampler allocator appropriate for this planner.
	// Simpler allocator: construct a CTR fallback sampler and, if informed
	// sampling is enabled, wrap it with our PINNs-based informed-state
	// sampler. This avoids complex planner-level queries to
	// OptimizationObjective::allocInformedStateSampler which previously
	// introduced parsing/templating issues during compilation.
	this->m_space->setStateSamplerAllocator([this, useInformed](const ompl::base::StateSpace *space) -> ompl::base::StateSamplerPtr
											{
			auto validityChecker = std::dynamic_pointer_cast<CTR_StateValidityChecker<Nodes, controlInputs>>(m_stateValidityChecker);
			if (!validityChecker)
				throw std::runtime_error("Expected CTR_StateValidityChecker in Planner::plan() sampler allocator");

			// Fallback uniform/CTR sampler
			auto fallback = std::make_shared<CTR_StateSampler<Nodes, controlInputs>>(space, *validityChecker, m_CTR_model);

			// Extract parameters from Planner's bounds and validity checker
			const double beta1_min = m_coordBound->low[0UL];
			const double beta2_min = m_coordBound->low[1UL];
			const double beta3_min = m_coordBound->low[2UL];
			const double clearance = m_CTR_model.getStageThickness();

			// Set parameters on the fallback sampler
			fallback->setParameters(beta1_min, beta2_min, beta3_min, clearance);

			if (!useInformed)
			{
				this->m_informedSampler = fallback;
				return fallback;
			}

			// Avoid recursion during informed sampler construction
			if (this->m_constructingInformedSampler)
			{
				this->m_informedSampler = fallback;
				return fallback;
			}

			// Build a cost getter function for the informed sampler
			auto getCostFunc = [this]() -> ompl::base::Cost
			{
				auto path = std::static_pointer_cast<ompl::geometric::PathGeometric>(this->m_pdef->getSolutionPath());
				if (!path)
					return ompl::base::Cost(std::numeric_limits<double>::infinity());
				auto opt = this->m_pdef->getOptimizationObjective();
				if (!opt)
					return ompl::base::Cost(std::numeric_limits<double>::infinity());
				return path->cost(opt);
			};

			this->m_constructingInformedSampler = true;
			auto informed = std::make_shared<CTR_PINNsInformedStateSampler<Nodes, controlInputs>>(this->m_pdef, getCostFunc, *validityChecker, m_CTR_model, fallback, 1000u);
			this->m_constructingInformedSampler = false;

			if (this->m_goalState && this->m_goalState->get())
			{
				informed->setGoalState(this->m_goalState->get());
			}

			informed->setTipRadius(this->m_informedTipRadius);
			informed->setMaxAttempts(this->m_informedMaxAttempts);

			this->m_informedSampler = informed;
			return informed; });

	// Re-setup the SpaceInformation so the new allocator is used to create samplers
	this->m_si->setup();

	// If we plan to use an informed sampler, estimate how useful the
	// optimization objective's cost-to-go heuristic is by sampling a few
	// states (via the fallback sampler) and comparing the objective's
	// cost-to-go to the conservative state-space baseline (ctrCostToGoal).
	// If the heuristic only provides a very small improvement we lower the
	// informed-sampler bias to avoid expensive PINNs/IK attempts.
	if (useInformed && this->m_informedSampler)
	{
		auto inf = std::dynamic_pointer_cast<CTR_PINNsInformedSampler<Nodes, controlInputs>>(this->m_informedSampler);
		if (inf)
		{
			auto opt = this->m_pdef->getOptimizationObjective();
			auto goalPtr = this->m_pdef->getGoal().get();
			if (opt && goalPtr)
			{
				// Create a temporary fallback sampler to draw unbiased samples
				auto validityChecker = std::dynamic_pointer_cast<CTR_StateValidityChecker<Nodes, controlInputs>>(m_stateValidityChecker);
				if (!validityChecker)
					throw std::runtime_error("Expected CTR_StateValidityChecker when creating temporary fallback sampler");
				auto fallback = std::make_shared<CTR_StateSampler<Nodes, controlInputs>>(this->m_space.get(), *validityChecker, m_CTR_model);
				// set same parameters as allocator would
				const double beta1_min = m_coordBound->low[0UL];
				const double beta2_min = m_coordBound->low[1UL];
				const double beta3_min = m_coordBound->low[2UL];
				const double clearance = m_CTR_model.getStageThickness();
				fallback->setParameters(beta1_min, beta2_min, beta3_min, clearance);

				// sample a small number of states and compute relative improvement
				constexpr std::size_t N = 8;
				double sumImprovement = 0.00;
				std::size_t counted = 0;
				for (std::size_t i = 0; i < N; ++i)
				{
					auto *s = this->m_space->allocState();
					try
					{
						fallback->sampleUniform(s);
						double baseline = ctrCostToGoal(s, goalPtr).value();
						double objVal = 0.00;
						try
						{
							objVal = this->m_pdef->getOptimizationObjective()->costToGo(s, goalPtr).value();
						}
						catch (...)
						{
							objVal = baseline;
						}

						if (baseline > 1.00E-12)
						{
							double improvement = std::max(0.00, (baseline - objVal) / baseline);
							sumImprovement += improvement;
							++counted;
						}
					}
					catch (...)
					{
					}
					this->m_space->freeState(s);
				}

				double avgImprovement = (counted > 0) ? (sumImprovement / static_cast<double>(counted)) : 0.00;

				// Map average improvement to a practical bias value: weak heuristics -> low bias
				double newBias = 0.50; // default
				if (avgImprovement < 0.05)
					newBias = 0.10; // very weak
				else if (avgImprovement < 0.15)
					newBias = 0.25; // weak
				else
					newBias = 0.50; // reasonable

				inf->setBias(newBias);
				logging::debug("Adjusted informed-sampler bias to ", newBias, " (avg heuristic improvement=", avgImprovement, ")");
			}
		}
	}

	// Construct the optimal planner specified the plannerType argument.
	this->m_optimizingPlanner = this->allocatePlanner(plannerType);

	/*
							____ SETTING THE PLANNER'S RANGE ____

		1. The range typically refers to the maximum distance a planner is allowed to extend in the configuration space while attempting to connect two points
		2. Choosing an appropriate range is crucial for the performance of the planner. Too small of a range might result in a planner that explores the configuration space too slowly, while too large of a range might lead to inefficiencies or failure to find solutions. The optimal range often depends on the specific characteristics of the planning problem and the environment. It's usually a parameter that needs to be tuned based on experimentation and domain knowledge.
		3. In the process of randomly selecting states in the state space to attempt to go towards, the algorithm may in fact choose the actual goal state, if it knows it, with some probability. This probability is a real number between 0.0 and 1.0; its value should usually be around 0.05 and should not be too large. It is probably a good idea to use the default value.
	*/

	const double extent = m_space->getMaximumExtent();
	const double defaultRange = 3.00E-4 * extent; // 0.03% of maximum extent

	// Diagnostic prints to help debug rewiring radius computation
	logging::debug("state space dimension = ", m_space->getDimension());
	logging::debug("state space maximum extent = ", extent);
	logging::debug("defaultRange (scaled extent) = ", defaultRange);
	if (m_coordBound)
	{
		std::ostringstream oss;
		oss << "coord bounds: ";
		for (std::size_t i = 0; i < m_coordBound->low.size(); ++i)
		{
			oss << "[" << m_coordBound->low[i] << "," << m_coordBound->high[i] << "] ";
		}
		logging::debug(oss.str());
	}

	switch (plannerType)
	{
	case optimalPlanner::PLANNER_RRTSTAR:
		// range represents the maximum length of a motion to be added in the tree of motions
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["goal_bias"] = 0.005;
		this->m_optimizingPlanner->params()["delay_collision_checking"] = true;
		this->m_optimizingPlanner->params()["rewire_factor"] = 1.50; // Recommended value: 1.0 to 2.0.
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		this->m_optimizingPlanner->params()["number_sampling_attempts"] = 5000;
		this->m_optimizingPlanner->params()["tree_pruning"] = false;
		this->m_optimizingPlanner->params()["prune_threshold"] = 0.00;
		this->m_optimizingPlanner->params()["informed_sampling"] = true;
		this->m_optimizingPlanner->params()["new_state_rejection"] = false;
		this->m_optimizingPlanner->params()["use_admissible_heuristic"] = true;
		break;

	case optimalPlanner::PLANNER_RLRT:
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["goal_bias"] = 0.005;
		this->m_optimizingPlanner->params()["keep_last_valid"] = false;
		break;

	case optimalPlanner::PLANNER_RRT:
		// range represents the maximum length of a motion to be added in the tree of motions
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["goal_bias"] = 0.005;
		this->m_optimizingPlanner->params()["intermediate_states"] = true;
		break;

	case optimalPlanner::PLANNER_RRT_CONNECT:
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["intermediate_states"] = true;
		break;

	case optimalPlanner::PLANNER_INF_RRTSTAR:
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["goal_bias"] = 0.01;
		this->m_optimizingPlanner->params()["delay_collision_checking"] = true;
		this->m_optimizingPlanner->params()["rewire_factor"] = 1.50; // Recommended value: 1.0 to 2.0.
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		this->m_optimizingPlanner->params()["number_sampling_attempts"] = 500;
		this->m_optimizingPlanner->params()["ordered_sampling"] = false;
		this->m_optimizingPlanner->params()["ordering_batch_size"] = 1;
		this->m_optimizingPlanner->params()["prune_threshold"] = 0.005;
		break;

	case optimalPlanner::PLANNER_SORRTSTAR:
		this->m_optimizingPlanner->params()["range"] = defaultRange;
		this->m_optimizingPlanner->params()["goal_bias"] = 0.005;
		this->m_optimizingPlanner->params()["delay_collision_checking"] = true;
		this->m_optimizingPlanner->params()["rewire_factor"] = 1.75; // Recommended value: 1.0 to 2.0.
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		this->m_optimizingPlanner->params()["number_sampling_attempts"] = 100;
		this->m_optimizingPlanner->params()["ordered_sampling"] = false;
		this->m_optimizingPlanner->params()["prune_threshold"] = 0.005;
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		break;

	case optimalPlanner::PLANNER_BITSTAR:
		// The number of samples to generate on each batch.
		this->m_optimizingPlanner->params()["samples_per_batch"] = 10000;
		// The factor by which to increase the connection radius.
		this->m_optimizingPlanner->params()["rewire_factor"] = 1.75;
		// Whether to use k-nearest neighbors or a radius search.
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		// The fraction of the solution cost at which to prune states.
		this->m_optimizingPlanner->params()["use_graph_pruning"] = true;
		this->m_optimizingPlanner->params()["drop_unconnected_samples_on_prune"] = true;
		this->m_optimizingPlanner->params()["delay_rewiring_to_first_solution"] = false;
		this->m_optimizingPlanner->params()["find_approximate_solutions"] = true;
		this->m_optimizingPlanner->params()["prune_threshold_as_fractional_cost_change"] = true;
		this->m_optimizingPlanner->params()["stop_on_each_solution_improvement"] = false;
		this->m_optimizingPlanner->params()["use_just_in_time_sampling"] = true;
		break;

	case optimalPlanner::PLANNER_AITSTAR:
		// The number of samples to generate on each batch.
		this->m_optimizingPlanner->params()["samples_per_batch"] = 1000;
		// The factor by which to increase the connection radius.
		this->m_optimizingPlanner->params()["rewire_factor"] = 1.75;
		// Whether to use k-nearest neighbors or a radius search.
		this->m_optimizingPlanner->params()["use_k_nearest"] = false;
		break;

	case optimalPlanner::PLANNER_BFMTSTAR:
	{
		auto &params = this->m_optimizingPlanner->params();
		// num_samples: total number of uniformly drawn states in each forward/backward frontier expansion.
		params["num_samples"] = 2000;
		// radius_multiplier: scales the connection radius relative to the theoretical optimum ( > 1 widens connectivity ).
		params["radius_multiplier"] = 1.50;
		// balanced: alternate between forward/backward trees to maintain similar frontier sizes.
		params["balanced"] = true;
		// cache_cc: cache collision-check queries so repeated edge evaluations are cheap.
		params["cache_cc"] = true;
		// extended_fmt: enable the BFMT* extension that lazily rewires when cheaper edges appear.
		params["extended_fmt"] = true;
		// heuristics: use cost-to-go heuristics to sort the wavefront and focus expansions.
		params["heuristics"] = true;
		// nearest_k: switch between radius-based (false) and k-nearest (true) neighbor selection.
		params["nearest_k"] = false;
		// optimality: keep asymptotic optimality guarantees (set false to get faster but sub-optimal results).
		params["optimality"] = true;
		break;
	}

	case optimalPlanner::PLANNER_CFOREST:
	{
		// Configure a CForest of RRT* planners. Create per-thread RRT* instances
		// and configure each instance with the problem-specific defaultRange and
		// a small set of tuned parameters so all threads behave consistently.

		auto cforest = std::make_shared<ompl::geometric::CForest>(m_si);

		// IMPORTANT: set the problem definition on the CForest before
		// creating planner instances so that addPlannerInstanceInternal
		// can propagate the ProblemDefinition to each created planner.
		cforest->setProblemDefinition(this->m_pdef);

		// Number of threads: at least 2, otherwise use hardware concurrency
		const unsigned numThreads = std::max(2u, std::thread::hardware_concurrency());

		// Use the templated helper to create the planner instances with the
		// correct wrapped SpaceInformation. Then retrieve each created
		// instance and configure it.
		cforest->addPlannerInstances<ompl::geometric::InformedRRTstar>(numThreads); // InformedRRTstar

		for (unsigned i = 0; i < numThreads; ++i)
		{
			auto &plannerPtr = cforest->getPlannerInstance(i);
			auto rrt = std::dynamic_pointer_cast<ompl::geometric::InformedRRTstar>(plannerPtr);
			if (!rrt)
				continue;

			// Configure commonly used RRT* parameters (match RRT*/InformedRRT* tuning above)
			rrt->params()["range"] = defaultRange;
			rrt->params()["goal_bias"] = 0.005;
			rrt->params()["delay_collision_checking"] = true;
			rrt->params()["rewire_factor"] = 1.75; // Recommended value: 1.0 to 2.0.
			rrt->params()["use_k_nearest"] = false;
			rrt->params()["number_sampling_attempts"] = 100;
			rrt->params()["ordered_sampling"] = false;
			rrt->params()["ordering_batch_size"] = 1;
			rrt->params()["prune_threshold"] = 0.005;
		}

		cforest->setNumThreads(numThreads);
		cforest->setFocusSearch(false); // Let planners explore independently
		this->m_optimizingPlanner = cforest;
		break;
	}

	case optimalPlanner::PLANNER_PRMSTAR:
		// this->m_optimizingPlanner->params()["range"] = defaultRange;
		// this->m_optimizingPlanner->params()["goal_bias"] = 0.025;
		// this->m_optimizingPlanner->params()["max_nearest_neighbors"] = 20;
		// this->m_optimizingPlanner->params()["num_samples"] = 3000;
		break;

	case optimalPlanner::PLANNER_PRM:
		this->m_optimizingPlanner->params()["max_nearest_neighbors"] = 5000;
		// this->m_optimizingPlanner->params()["max_neighbors"] = 10;
		// this->m_optimizingPlanner->params()["connection_attempts"] = 10;

		// this->m_optimizingPlanner->params()["num_samples"] = 1000;
		break;

	default:
		throw std::runtime_error("Planner not supported!");
	}

	// Set the problem instance for the specified planner to solve
	this->m_optimizingPlanner->setProblemDefinition(this->m_pdef);
	if (!m_optimizingPlanner->isSetup())
		m_optimizingPlanner->setup();

	// Print the planner properties/settings after it has been fully configured
	if (this->m_optimizingPlanner)
		this->m_optimizingPlanner->printProperties(std::cout);

	m_optimizingPlanner->printSettings(std::cout);

	// attempt to solve the planning problem in the given runtime
	// Debug: print start/goal/objective costs to diagnose zero-target issues
	{
		auto opt = this->m_pdef->getOptimizationObjective();
		const ompl::base::Goal *goal = this->m_pdef->getGoal().get();
		if (opt && goal)
		{
			try
			{
				const ompl::base::State *start = nullptr;
				try
				{
					start = this->m_pdef->getStartState(0);
				}
				catch (...)
				{
					start = nullptr;
				}
				// If goal is a GoalState, extract the underlying state for stateCost
				const ompl::base::State *goalState = nullptr;
				if (goal->hasType(ompl::base::GoalType::GOAL_STATE))
				{
					goalState = goal->as<ompl::base::GoalState>()->getState();
				}
				logging::debug("objective present.");
				if (start)
					logging::debug("start state cost = ", opt->stateCost(start).value());
				if (goalState)
					logging::debug("goal state cost = ", opt->stateCost(goalState).value());
				try
				{
					double ctg = opt->costToGo(start, goal).value();
					logging::debug("costToGo(start,goal) = ", ctg);
				}
				catch (const std::exception &e)
				{
					logging::debug("costToGo threw: ", e.what());
				}
			}
			catch (const std::exception &e)
			{
				logging::debug("exception while computing costs: ", e.what());
			}
		}
	}

	// Ensure any previously recorded solution paths (e.g., trivial goal-only
	// paths) are cleared so the optimizer does not treat an initial zero-cost
	// "solution" as the current best and thereby make the informed subset
	// empty. This avoids the planner seeking an impossible improvement (cost<0).
	if (this->m_pdef)
		this->m_pdef->clearSolutionPaths();

	this->m_solved = this->m_optimizingPlanner->solve(runTime);

	if (this->m_solved == ompl::base::PlannerStatus::EXACT_SOLUTION)
	{
		std::cout << "Exact solution found." << std::endl;
		return 0;
	}
	else if (this->m_solved == ompl::base::PlannerStatus::APPROXIMATE_SOLUTION)
	{
		std::cout << "Approximate solution found." << std::endl;
		return 0;
	}
	else
	{
		std::cout << "No solution found." << std::endl;
		return 1;
	}
}

template <size_t Nodes, size_t controlInputs>
int Planner<Nodes, controlInputs>::replan(const double runTime)
{
	this->m_solved = this->m_optimizingPlanner->solve(runTime);

	if (this->m_solved == ompl::base::PlannerStatus::EXACT_SOLUTION)
		{std::cout << "Exact solution found." << std::endl;
		return 0;}
	else if (this->m_solved == ompl::base::PlannerStatus::APPROXIMATE_SOLUTION)
		{std::cout << "Approximate solution found." << std::endl;
		return 0;}
	else
		{std::cout << "No solution found." << std::endl;
		return 1;}
}

template <size_t Nodes, size_t controlInputs>
void Planner<Nodes, controlInputs>::writeSolutionToFile(const std::string &outputFile)
{
	if ((this->m_solved == ompl::base::PlannerStatus::EXACT_SOLUTION) || (this->m_solved == ompl::base::PlannerStatus::APPROXIMATE_SOLUTION))
	{
		if (!outputFile.empty())
		{
			const std::filesystem::path tmpDir = "../../OutputFiles";
			const std::filesystem::path fileName = tmpDir / outputFile;

			// Ensure the directory exists
			if (!std::filesystem::exists(tmpDir))
			{
				std::filesystem::create_directories(tmpDir);
			}

			std::ofstream outFile(fileName, std::ios::out);

			if (outFile.is_open())
			{
				// Set precision for the entire file
				outFile << std::fixed << std::setprecision(10);

				auto path = std::static_pointer_cast<ompl::geometric::PathGeometric>(this->m_pdef->getSolutionPath());
				if (!path)
					throw std::runtime_error("No solution path available to write.");

				// Loop through the states and write each state as a line in CSV format
				for (const auto &state : path->getStates())
				{
					// Assuming your state is of a type that can be converted to a string with comma-separated values
					auto *pos = state->as<ompl::base::RealVectorStateSpace::StateType>();
					if (pos)
					{
						for (size_t i = 0UL; i < controlInputs; ++i)
						{
							if (i > 0)
								outFile << ",";
							outFile << pos->values[i];
						}
						outFile << std::endl;
					}
					else
					{
						throw std::runtime_error("Error: Unexpected state type.");
					}
				}

				outFile.close();
				// Inform the user that the file was successfully written
				std::cout << "Motion plan successfully written to: "
						  << std::filesystem::absolute(fileName) << std::endl;
			}
			else
			{
				throw std::runtime_error("Error: Could not save surgical planning to file: " + fileName.string());
			}
		}
	}
	else
		std::cout << "No solution found." << std::endl;
}

template <size_t Nodes, size_t controlInputs>
void Planner<Nodes, controlInputs>::analyzeSolution(bool dumpCSV, const std::string &csvPath)
{
	using StateType = ompl::base::RealVectorStateSpace::StateType;

	if (!(this->m_solved == ompl::base::PlannerStatus::EXACT_SOLUTION || this->m_solved == ompl::base::PlannerStatus::APPROXIMATE_SOLUTION))
	{
		if (logging::verbose)
			std::cout << "Skipping diagnostics: planner has no solution." << std::endl;
		return;
	}

	auto path = std::static_pointer_cast<ompl::geometric::PathGeometric>(this->m_pdef->getSolutionPath());
	if (!path || path->getStateCount() == 0)
	{
		if (logging::verbose)
			std::cout << "No states in solution path to analyze." << std::endl;
		return;
	}

	// Pull start/goal prismatic for progress; goal revolute for angle diffs
	if (!this->m_startState || !this->m_goalState || !this->m_startState->get() || !this->m_goalState->get())
	{
		if (logging::verbose)
			std::cout << "Start/goal states unavailable for analysis." << std::endl;
		return;
	}
	const auto *sstate = this->m_startState->get()->as<StateType>();
	const auto *gstate = this->m_goalState->get()->as<StateType>();
	if (!sstate || !gstate)
	{
		if (logging::verbose)
			std::cout << "Start/goal states unavailable for analysis." << std::endl;
		return;
	}

	const bool printDiagnostics = logging::verbose;
	if (printDiagnostics)
	{
		std::cout << std::fixed << std::setprecision(6);
		std::cout << "Diagnostics: idx | path_frac | p | rev_base | scale | rev_scaled | rev_weighted | backbone_raw | prismatic_weighted | backbone_coupled | mismatch | gating | alignment_progress | lag_raw | lag | composite | max_angle_err_deg" << std::endl;
	}

	auto clamp01 = [](double x) { return std::max(0.0, std::min(1.0, x)); };

	// Prismatic start->goal vector and denom for projection progress p
	const double sx = sstate->values[0UL], sy = sstate->values[1UL], sz = sstate->values[2UL];
	const double gx = gstate->values[0UL], gy = gstate->values[1UL], gz = gstate->values[2UL];
	const double vx = gx - sx, vy = gy - sy, vz = gz - sz;
	const double prismaticDenom = vx * vx + vy * vy + vz * vz;

	// Revolute goal angles
	const double a1g = gstate->values[3UL], a2g = gstate->values[4UL], a3g = gstate->values[5UL];

	const std::size_t N = path->getStateCount();
	std::vector<double> cumulativeLengths(N, 0.0);
	double totalLength = 0.0;
	if (this->m_si)
	{
		for (std::size_t i = 1; i < N; ++i)
		{
			double seg = this->m_si->distance(path->getState(i - 1), path->getState(i));
			totalLength += seg;
			cumulativeLengths[i] = totalLength;
		}
	}
	const double invTotalLength = (totalLength > 1.0e-9) ? 1.0 / totalLength : 0.0;

	// Constants from CTR_RevoluteJointObjective (reduced penalties)
	constexpr double c1 = 2000.0;
	constexpr double c2 = 1000.0;
	constexpr double c3 = 400.0;

	// Progress scaling (singular rear-loaded) now in CTR_RevoluteJointObjective: alpha=120, gamma=1.5
	constexpr double alpha = 120.0;
	constexpr double gamma = 1.5;

	auto shortest = [](double a, double b) {
		double d = a - b;
		while (d > M_PI)
			d -= 2.0 * M_PI;
		while (d < -M_PI)
			d += 2.0 * M_PI;
		return std::fabs(d);
	};

	// Backbone weights from CTR_BackboneLengthObjective
	constexpr double k1 = 1000.0;
	constexpr double k2 = 6000.0;
	constexpr double k3 = 3000.0;
	constexpr double k4 = 500.0;

	// Composite parameters (synchronized with CompositeStateCostIntegral)
	const double w_backbone = CompositeParams::w_backbone;
	const double w_revolute = CompositeParams::w_revolute;
	const double k_coupling = CompositeParams::k_coupling;
	const double w_mismatch = CompositeParams::w_mismatch;
	const double k_frontload = CompositeParams::k_frontload;
	const double tau_frontload = CompositeParams::tau_frontload;
	const double p_front_gate = CompositeParams::p_front_gate;
	const double angle_front_gate_thresh = CompositeParams::angle_front_gate_thresh;
	const double w_front_gate = CompositeParams::w_front_gate;
	const double p_gate = CompositeParams::p_gate;
	const double angle_gate_thresh = CompositeParams::angle_gate_thresh;
	const double w_gate = CompositeParams::w_gate;
	const double w_progress_lag = CompositeParams::w_progress_lag;
	const double lag_slack = CompositeParams::lag_slack;
	const double lag_power = CompositeParams::lag_power;

	// CSV output
	std::ofstream csv;
	if (dumpCSV)
	{
		const std::filesystem::path tmpDir = "../../OutputFiles";
		if (!std::filesystem::exists(tmpDir))
			std::filesystem::create_directories(tmpDir);
		const std::filesystem::path out = tmpDir / csvPath;
		csv.open(out, std::ios::out);
		if (csv.is_open())
		{
			csv << std::fixed << std::setprecision(10);
			csv << "index,path_fraction,p,rev_base,scale,rev_scaled,rev_weighted,backbone_raw,prismatic_weighted,backbone_coupled,mismatch,gating,alignment_progress,lag_raw,lag,composite,max_angle_err_deg\n";
		}
	}

	std::size_t idx_first_small_err = N; // where max angle error < 1 deg
	double firstSmallErrFrac = -1.0;
	double firstSmallErrLength = 0.0;
	const double err_thresh = M_PI / 180.0; // 1 deg in rad
	double initialMaxErrDeg = -1.0;

	for (std::size_t i = 0; i < N; ++i)
	{
		const auto *st = path->getState(i)->as<StateType>();
		const double pathFrac = (totalLength > 1.0e-9) ? cumulativeLengths[i] * invTotalLength : ((N > 1) ? static_cast<double>(i) / static_cast<double>(N - 1) : 1.0);
		// Progress p
		double p = 0.0;
		if (prismaticDenom > 1.0e-12)
		{
			const double wx = st->values[0UL] - sx;
			const double wy = st->values[1UL] - sy;
			const double wz = st->values[2UL] - sz;
			p = clamp01((wx * vx + wy * vy + wz * vz) / prismaticDenom);
		}
		else
		{
			// Fallback: normalize distance from origin to goal in 3D prismatic
			const double dgoal2 = gx * gx + gy * gy + gz * gz;
			const double dcur2 = st->values[0UL] * st->values[0UL] + st->values[1UL] * st->values[1UL] + st->values[2UL] * st->values[2UL];
			p = (dgoal2 > 1.00E-12) ? clamp01(std::sqrt(dcur2 / dgoal2)) : 0.0;
		}

		// Revolute contributions
		const double d1 = shortest(st->values[3UL], a1g);
		const double d2 = shortest(st->values[4UL], a2g);
		const double d3 = shortest(st->values[5UL], a3g);
		const double rev_base = c1 * d1 + c2 * d2 + c3 * d3;
		// Singular rear-loaded scaling applied in objective: 1 + alpha * (p / (1-p))^gamma
		constexpr double eps = 1.0e-3;
		const double scaleDenom = std::max(eps, 1.0 - p);
		const double ratio = std::max(0.0, p) / scaleDenom;
		const double boundedRatio = std::min(1.0e6, ratio);
		const double scale = 1.0 + alpha * std::pow(boundedRatio, gamma);
		const double rev_scaled = rev_base * scale;
		const double revoluteWeighted = w_revolute * rev_scaled;

		// Backbone cost via CTR model
		blaze::StaticVector<double, controlInputs> q;
		for (std::size_t j = 0; j < controlInputs; ++j)
			q[j] = st->values[j];
		const auto ends = this->m_CTR_model.get_s_ends(q);
		const double backbone_raw = k1 * ends[0UL] + k2 * (ends[0UL] - ends[1UL]) + k3 * (ends[1UL] - ends[2UL]) + k4 * (ends[0UL] - ends[2UL]);
		const double prismaticWeighted = w_backbone * backbone_raw;

		const double max_err_deg = 180.0 / M_PI * std::max(d1, std::max(d2, d3));
		if (initialMaxErrDeg < 0.0)
			initialMaxErrDeg = max_err_deg > 1.00E-9 ? max_err_deg : 1.0;
		double normAngleErr = max_err_deg / initialMaxErrDeg;
		normAngleErr = std::clamp(normAngleErr, 0.0, 1.0);

		const double backbone_coupled = w_backbone * backbone_raw * (1.0 + k_coupling * normAngleErr);
		const double frontFactor = 1.0 + k_frontload * std::exp(-p / tau_frontload);
		const double mismatch = w_mismatch * normAngleErr * frontFactor;
		double gating = 0.0;
		if (p < p_front_gate && normAngleErr > angle_front_gate_thresh)
			gating += w_front_gate * (p_front_gate - p) * (normAngleErr - angle_front_gate_thresh);
		if (p > p_gate && normAngleErr > angle_gate_thresh)
			gating += w_gate * (p - p_gate) * (normAngleErr - angle_gate_thresh);
		const double alignmentProgress = std::clamp(1.0 - normAngleErr, 0.0, 1.0);
		const double lagRaw = p - (alignmentProgress + lag_slack);
		const double lagPenalty = (lagRaw > 0.0) ? w_progress_lag * std::pow(lagRaw, lag_power) : 0.0;

		const double composite = backbone_coupled + revoluteWeighted + mismatch + gating + lagPenalty;

		if (idx_first_small_err == N && std::max(d1, std::max(d2, d3)) < err_thresh)
		{
			idx_first_small_err = i;
			firstSmallErrFrac = pathFrac;
			firstSmallErrLength = cumulativeLengths[i];
		}

		// Print every state; for long paths this is verbose but intentional for diagnostics
		if (printDiagnostics)
		{
			std::cout << i << " | " << pathFrac << " | " << p << " | " << rev_base << " | " << scale << " | " << rev_scaled << " | " << revoluteWeighted << " | " << backbone_raw << " | " << prismaticWeighted << " | " << backbone_coupled << " | " << mismatch << " | " << gating << " | " << alignmentProgress << " | " << lagRaw << " | " << lagPenalty << " | " << composite << " | " << max_err_deg << std::endl;
		}

		if (csv.is_open())
			csv << i << "," << pathFrac << "," << p << "," << rev_base << "," << scale << "," << rev_scaled << "," << revoluteWeighted << "," << backbone_raw << "," << prismaticWeighted << "," << backbone_coupled << "," << mismatch << "," << gating << "," << alignmentProgress << "," << lagRaw << "," << lagPenalty << "," << composite << "," << max_err_deg << "\n";
	}

	if (csv.is_open())
	{
		csv.close();
		logging::debug("Diagnostics CSV written.");
	}

	if (printDiagnostics)
	{
		if (idx_first_small_err < N)
		{
			double frac = (firstSmallErrFrac >= 0.0) ? firstSmallErrFrac : ((N > 1) ? static_cast<double>(idx_first_small_err) / static_cast<double>(N - 1) : 1.0);
			double arcLen = firstSmallErrLength;
			std::cout << "Revolute angle error < 1 deg achieved at state index " << idx_first_small_err
				  << " (" << std::setprecision(3) << 100.0 * frac << "% of cumulative path length";
			if (totalLength > 1.0e-9)
				std::cout << ", arc length = " << std::setprecision(4) << arcLen << " (state-space units))" << std::endl;
			else
				std::cout << ")" << std::endl;
		}
		else
		{
			std::cout << "Revolute angle error did not drop below 1 deg along the path." << std::endl;
		}
	}
}

template <size_t Nodes, size_t controlInputs>
void Planner<Nodes, controlInputs>::cleanup()
{
	// Clear planner-specific state first to release any references to ProblemDefinition/SpaceInformation
	if (this->m_optimizingPlanner)
	{
		try
		{
			this->m_optimizingPlanner->clear();
		}
		catch (...)
		{
		}
		this->m_optimizingPlanner.reset();
	}

	// Clear problem definition states and paths (frees cloned start/goal states)
	if (this->m_pdef)
	{
		try
		{
			this->m_pdef->clearSolutionPaths();
			this->m_pdef->clearStartStates();
			this->m_pdef->clearGoal();
		}
		catch (...)
		{
		}
		this->m_pdef.reset();
	}

	// Reset samplers and validity/motion validators
	this->m_informedSampler.reset();
	this->m_stateValidityChecker.reset();

	if (this->m_si)
	{
		try
		{
			this->m_si->setStateValidityChecker(ompl::base::StateValidityCheckerPtr());
			this->m_si->setMotionValidator(ompl::base::MotionValidatorPtr());
		}
		catch (...)
		{
		}
		this->m_si.reset();
	}

	// Reset space and bounds
	this->m_space.reset();
	this->m_coordBound.reset();

	// Reset scoped states to release any underlying allocations
	this->m_startState.reset();
	this->m_goalState.reset();
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getRevoluteJointObjective(const std::array<double, 3UL> &goal)
{
	auto obj = std::make_shared<CTR_RevoluteJointObjective<Nodes, controlInputs>>(this->m_si, goal);

	// If start and goal prismatic values are available, wire them into the
	// revolute objective so it can compute progress-based scaling.
	try
	{
		if (this->m_startState && this->m_goalState && this->m_startState->get() && this->m_goalState->get())
		{
			const auto *sstate = this->m_startState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
			const auto *gstate = this->m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
			std::array<double, 3UL> startPrism{sstate->values[0UL], sstate->values[1UL], sstate->values[2UL]};
			std::array<double, 3UL> goalPrism{gstate->values[0UL], gstate->values[1UL], gstate->values[2UL]};
			obj->setPrismaticStartGoal(startPrism, goalPrism);
		}
	}
	catch (...)
	{ /* non-fatal: leave objective without prismatic bounds */
	}

	return obj;
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getPathLengthObjective()
{
	return std::make_shared<ompl::base::PathLengthOptimizationObjective>(this->m_si);
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getThresholdPathLengthObjctive()
{
	// Return a plain path-length optimization objective without a cost threshold.
	// Setting an infinite cost threshold causes planners to consider any finite
	// solution as meeting the threshold immediately which leads to early
	// termination. Leave thresholds out to allow continued optimization until
	// the termination condition (time, etc.) is met.
	return std::make_shared<ompl::base::PathLengthOptimizationObjective>(this->m_si);
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getClearanceObjective()
{
	return std::make_shared<CTR_ClearanceObjective<Nodes, controlInputs>>(this->m_si);
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::RevoluteJointsAndBackboneLengthObjective(const std::array<double, 3UL> &goal)
{
	auto backboneLengthObj(std::make_shared<CTR_BackboneLengthObjective<Nodes, controlInputs>>(this->m_si, this->m_CTR_model));
	auto revoluteJointObj(std::make_shared<CTR_RevoluteJointObjective<Nodes, controlInputs>>(this->m_si, goal));

	// Create a MultiOptimizationObjective subclass that forwards
	// allocInformedStateSampler() to its component objectives. OMPL's
	// default MultiOptimizationObjective does not forward this call,
	// which causes informed planners to fall back to rejection
	// sampling even when a component objective provides a direct
	// InformedSampler (e.g., the backbone-length objective).
	class MultiOptWithInformed : public ompl::base::MultiOptimizationObjective
	{
	public:
		using ompl::base::MultiOptimizationObjective::MultiOptimizationObjective;

		ompl::base::InformedSamplerPtr allocInformedStateSampler(const ompl::base::ProblemDefinitionPtr &probDef,
																 unsigned int maxNumberCalls) const override
		{
				logging::debug("MultiOptWithInformed::allocInformedStateSampler called");
			// Iterate component objectives and return the first non-null
			// informed sampler provided by a component. This keeps behavior
			// simple and leverages any specialized informed sampling
			// implemented by component objectives.
			for (unsigned int i = 0; i < this->getObjectiveCount(); ++i)
			{
				const auto &comp = this->getObjective(i);
				if (!comp)
					continue;
				try
				{
						std::ostringstream oss;
						oss << "querying component " << i << " for informed sampler";
						logging::debug(oss.str());
					auto inf = comp->allocInformedStateSampler(probDef, maxNumberCalls);
					if (inf)
					{
							logging::debug("component ", i, " returned non-null informed sampler");
						return inf;
					}
					else
					{
							logging::debug("component ", i, " returned null informed sampler");
					}
				}
				catch (...)
				{
						logging::debug("component ", i, " allocInformedStateSampler threw");
					// Ignore component failures and try next
				}
			}
			return ompl::base::InformedSamplerPtr();
		}
	};

	// Instead of using a MultiOptimizationObjective (which OMPL's informed
	// sampling path doesn't treat as a StateCostIntegralObjective), create
	// a composite StateCostIntegralObjective that represents the weighted
	// sum of the backbone-length and revolute-joint objectives. This class
	// will expose a proper allocInformedStateSampler() (forwarding to the
	// backbone objective) so informed planners can use direct informed
	// sampling.
	class CompositeStateCostIntegral : public ompl::base::StateCostIntegralObjective
	{
	public:
		CompositeStateCostIntegral(const ompl::base::SpaceInformationPtr &si,
							   const ompl::base::OptimizationObjectivePtr &backbone,
							   const ompl::base::OptimizationObjectivePtr &revolute,
							   double wb,
							   double wr,
							   PINNs<Nodes, controlInputs> &ctrModel,
							   const ompl::base::StateValidityCheckerPtr &stateVC,
							   const std::shared_ptr<ompl::base::RealVectorBounds> &coordBound,
							   const std::array<double,3UL> &goalAngles,
							   const std::array<double,3UL> &prismStart,
							   const std::array<double,3UL> &prismGoal)
			: ompl::base::StateCostIntegralObjective(si, true), m_backbone(backbone), m_revolute(revolute), w_backbone(wb), w_revolute(wr), m_si(si), m_ctrModel(ctrModel), m_stateVC(stateVC), m_coordBound(coordBound), m_goalAngles(goalAngles), m_prismStart(prismStart), m_prismGoal(prismGoal)
		{
			// Pre-compute initial max angle error (degrees) for normalization
			m_initialMaxAngleErrDeg = computeMaxAngleErrDeg(prismStart[0], prismStart[1], prismStart[2], goalAngles);
			if (m_initialMaxAngleErrDeg < 1.00E-9)
				m_initialMaxAngleErrDeg = 1.0; // avoid divide by zero
		}

		ompl::base::Cost stateCost(const ompl::base::State *s) const override
		{
			// Raw component costs
			double backboneRaw = (m_backbone) ? m_backbone->stateCost(s).value() : 0.0;
			double revoluteScaled = (m_revolute) ? m_revolute->stateCost(s).value() : 0.0;

			// Current max angle error (degrees) for normalization
			const auto *rv = s->as<ompl::base::RealVectorStateSpace::StateType>();
			double maxErrDeg = computeMaxAngleErrDeg(rv->values[3], rv->values[4], rv->values[5], m_goalAngles);
			double normAngleErr = maxErrDeg / m_initialMaxAngleErrDeg;
			if (normAngleErr < 0.0) normAngleErr = 0.0;
			if (normAngleErr > 1.0) normAngleErr = 1.0;

			// Progress along prismatic deployment for mismatch term
			double p = computeProgress(rv);

			// Coupling: amplify backbone when angle error high (moderate k_coupling)
			double backboneCoupled = w_backbone * backboneRaw * (1.0 + k_coupling * normAngleErr);
			// Front-loaded mismatch term: strong early pressure that smoothly relaxes as deployment progresses
			double frontFactor = 1.0 + k_frontload * std::exp(-p / tau_frontload);
			double mismatch = w_mismatch * normAngleErr * frontFactor;
			// Soft gating penalties: encourage error reduction both before and after deployment midpoint
			double gatingPenalty = 0.0;
			if (p < p_front_gate && normAngleErr > angle_front_gate_thresh)
				gatingPenalty += w_front_gate * (p_front_gate - p) * (normAngleErr - angle_front_gate_thresh);
			if (p > p_gate && normAngleErr > angle_gate_thresh)
				gatingPenalty += w_gate * (p - p_gate) * (normAngleErr - angle_gate_thresh);
			double alignmentProgress = std::clamp(1.0 - normAngleErr, 0.0, 1.0);
			double lagRaw = p - (alignmentProgress + lag_slack);
			double lagPenalty = (lagRaw > 0.0) ? w_progress_lag * std::pow(lagRaw, lag_power) : 0.0;

			double total = backboneCoupled + w_revolute * revoluteScaled + mismatch + gatingPenalty + lagPenalty;
			return ompl::base::Cost(total);
		}

		bool hasCostToGoHeuristic() const
		{
			return (m_backbone && m_backbone->hasCostToGoHeuristic()) || (m_revolute && m_revolute->hasCostToGoHeuristic());
		}

		ompl::base::Cost costToGo(const ompl::base::State *s, const ompl::base::Goal *g) const
		{
			double sum = 0.0;
			if (m_backbone && m_backbone->hasCostToGoHeuristic())
				sum += w_backbone * m_backbone->costToGo(s, g).value();
			if (m_revolute && m_revolute->hasCostToGoHeuristic())
				sum += w_revolute * m_revolute->costToGo(s, g).value();
			return ompl::base::Cost(sum);
		}

		ompl::base::InformedSamplerPtr allocInformedStateSampler(const ompl::base::ProblemDefinitionPtr &probDef,
																 unsigned int maxNumberCalls) const override
		{
			logging::debug("CompositeStateCostIntegral::allocInformedStateSampler called");

			auto tryAlloc = [probDef, maxNumberCalls](const char *label, const ompl::base::OptimizationObjectivePtr &obj) -> ompl::base::InformedSamplerPtr
			{
				logging::debug("tryAlloc(", label, ") obj=", (obj ? "set" : "null"));
				if (!obj)
					return ompl::base::InformedSamplerPtr();
				try
				{
					logging::debug("invoking component sampler for ", label);
					return obj->allocInformedStateSampler(probDef, maxNumberCalls);
				}
				catch (...)
				{
					return ompl::base::InformedSamplerPtr();
				}
			};

			if (auto backboneSampler = tryAlloc("backbone", m_backbone))
				return backboneSampler;
			if (auto revoluteSampler = tryAlloc("revolute", m_revolute))
				return revoluteSampler;

			return ompl::base::InformedSamplerPtr();
		}

	private:
		// Helpers
		static double shortestDiff(double a, double b)
		{
			double d = a - b;
			while (d > M_PI) d -= 2.0 * M_PI;
			while (d < -M_PI) d += 2.0 * M_PI;
			return std::fabs(d);
		}
		static double computeMaxAngleErrDeg(double a1, double a2, double a3, const std::array<double,3UL> &goalAng)
		{
			double e1 = shortestDiff(a1, goalAng[0]);
			double e2 = shortestDiff(a2, goalAng[1]);
			double e3 = shortestDiff(a3, goalAng[2]);
			return 180.0 / M_PI * std::max(e1, std::max(e2, e3));
		}
		double computeProgress(const ompl::base::RealVectorStateSpace::StateType *rv) const
		{
			// Projection of current prismatic onto start->goal
			double sx = m_prismStart[0], sy = m_prismStart[1], sz = m_prismStart[2];
			double gx = m_prismGoal[0], gy = m_prismGoal[1], gz = m_prismGoal[2];
			double vx = gx - sx, vy = gy - sy, vz = gz - sz;
			double denom = vx*vx + vy*vy + vz*vz;
			if (denom <= 1.00E-12) return 0.0;
			double wx = rv->values[0] - sx;
			double wy = rv->values[1] - sy;
			double wz = rv->values[2] - sz;
			double p = (wx*vx + wy*vy + wz*vz) / denom;
			if (p < 0.0) p = 0.0; if (p > 1.0) p = 1.0;
			return p;
		}
		// Component objectives
		ompl::base::OptimizationObjectivePtr m_backbone;
		ompl::base::OptimizationObjectivePtr m_revolute;
		// Weights (retuned)
		double w_backbone{CompositeParams::w_backbone};
		double w_revolute{CompositeParams::w_revolute};
		// Coupling & mismatch parameters (retuned values)
		double k_coupling{CompositeParams::k_coupling};
		double w_mismatch{CompositeParams::w_mismatch};
		double k_frontload{CompositeParams::k_frontload};
		double tau_frontload{CompositeParams::tau_frontload};
		// Gating parameters
		double p_front_gate{CompositeParams::p_front_gate};
		double angle_front_gate_thresh{CompositeParams::angle_front_gate_thresh};
		double w_front_gate{CompositeParams::w_front_gate};
		double p_gate{CompositeParams::p_gate};
		double angle_gate_thresh{CompositeParams::angle_gate_thresh};
		double w_gate{CompositeParams::w_gate};
		double w_progress_lag{CompositeParams::w_progress_lag};
		double lag_slack{CompositeParams::lag_slack};
		double lag_power{CompositeParams::lag_power};
		// Geometry / model context
		ompl::base::SpaceInformationPtr m_si;
		PINNs<Nodes, controlInputs> &m_ctrModel;
		ompl::base::StateValidityCheckerPtr m_stateVC;
		std::shared_ptr<ompl::base::RealVectorBounds> m_coordBound;
		// Goal & progress baseline
		std::array<double,3UL> m_goalAngles{};
		std::array<double,3UL> m_prismStart{};
		std::array<double,3UL> m_prismGoal{};
		double m_initialMaxAngleErrDeg{1.0};
	};

	// Gather goal angles & prismatic start/goal for coupling and progress
	std::array<double,3UL> goalAngles = {goal[0], goal[1], goal[2]};
	std::array<double,3UL> prismStart{0.0,0.0,0.0};
	std::array<double,3UL> prismGoal{0.0,0.0,0.0};
	if (this->m_startState && this->m_goalState && this->m_startState->get() && this->m_goalState->get())
	{
		auto *ss = this->m_startState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
		auto *gs = this->m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>();
		prismStart = {ss->values[0], ss->values[1], ss->values[2]};
		prismGoal  = {gs->values[0], gs->values[1], gs->values[2]};
	}

	// Ensure the revolute objective has access to prismatic progress for rear-loaded scaling
	revoluteJointObj->setPrismaticStartGoal(prismStart, prismGoal);

	// Create and return the composite objective (weighted sum with coupling + rear-loaded mismatch + gating)
	auto composite = std::make_shared<CompositeStateCostIntegral>(this->m_si, backboneLengthObj, revoluteJointObj, CompositeParams::w_backbone, CompositeParams::w_revolute, this->m_CTR_model, this->m_stateValidityChecker, this->m_coordBound, goalAngles, prismStart, prismGoal);

	// Provide the same conservative combined cost-to-go heuristic as before
	composite->setCostToGoHeuristic([this, composite, backboneLengthObj, revoluteJointObj](const ompl::base::State *s, const ompl::base::Goal *g) -> ompl::base::Cost
									{
		double sum = 0.0;
		// backbone heuristic (scaled by new w_backbone)
		const auto &compB = backboneLengthObj;
		if (compB && compB->hasCostToGoHeuristic())
			sum += CompositeParams::w_backbone * compB->costToGo(s, g).value();
		// revolute heuristic (scaled by new w_revolute; coupling/mismatch/gating excluded for admissibility)
		const auto &compR = revoluteJointObj;
		if (compR && compR->hasCostToGoHeuristic())
			sum += CompositeParams::w_revolute * compR->costToGo(s, g).value();
		return ompl::base::Cost(sum); });

	return ompl::base::OptimizationObjectivePtr(composite);
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getBalancedObjective()
{
	auto lengthObj(std::make_shared<ompl::base::PathLengthOptimizationObjective>(this->m_si));
	auto clearObj(std::make_shared<CTR_ClearanceObjective<Nodes, controlInputs>>(this->m_si));

	auto opt(std::make_shared<ompl::base::MultiOptimizationObjective>(this->m_si));
	opt->addObjective(lengthObj, 10.00);
	opt->addObjective(clearObj, 1.00);

	// Provide a conservative combined cost-to-go: weighted sum of available
	// component heuristics. If a component lacks a heuristic, its contribution
	// is treated as zero (admissible underestimate).
	opt->setCostToGoHeuristic([opt](const ompl::base::State *s, const ompl::base::Goal *g)
								  -> ompl::base::Cost
							  {
		double sum = 0.0;
		for (std::size_t i = 0; i < opt->getObjectiveCount(); ++i)
		{
			const auto &comp = opt->getObjective(static_cast<unsigned int>(i));
			double w = opt->getObjectiveWeight(static_cast<unsigned int>(i));
			if (comp && comp->hasCostToGoHeuristic())
			{
				sum += w * comp->costToGo(s, g).value();
			}
		}
		return ompl::base::Cost(sum); });

	return ompl::base::OptimizationObjectivePtr(opt);
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getPathLengthObjWithCostToGo()
{
	auto obj(std::make_shared<ompl::base::PathLengthOptimizationObjective>(this->m_si));
	// Use a state-space admissible cost-to-go for the CTR state vector.
	// This provides a tighter, valid heuristic for informed sampling.
	obj->setCostToGoHeuristic(&ctrCostToGoal);

	return obj;
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::getBackboneLengthObjective()
{
	auto obj = std::make_shared<CTR_BackboneLengthObjective<Nodes, controlInputs>>(this->m_si, this->m_CTR_model);

	// Provide a PINNs-backed cost-to-go heuristic. We compute two heuristics:
	//  1) the existing conservative state-space heuristic (ctrCostToGoal), which
	//     is known to be admissible; and
	//  2) a tip-position Euclidean distance computed by the PINNs forward model
	//     (potentially much tighter). To preserve admissibility we return the
	//     minimum of these two values (min <= ctrStateSpace => still admissible).
	obj->setCostToGoHeuristic([this](const ompl::base::State *state, const ompl::base::Goal *goal) -> ompl::base::Cost
							  {
		using namespace ompl::base;

		// conservative admissible baseline (backbone-based, same units as the objective)
		auto backboneBaseline = [this](const ompl::base::State *s, const ompl::base::Goal *goal) -> ompl::base::Cost
		{
			using namespace ompl::base;
			if (!goal || !s)
				return Cost(std::numeric_limits<double>::infinity());

			// weights used in CTR_BackboneLengthObjective
			constexpr double c1 = 1000.00;
			constexpr double c2 = 6000.00;
			constexpr double c3 = 3000.00;
			constexpr double c4 = 500.00;

			// Helper to convert an ompl RealVector state to a blaze vector
			auto stateToTauLocal = [this](const State *s)
			{
				blaze::StaticVector<double, controlInputs> q;
				if (!s)
					return q; // zero-initialized
				const auto *rv = s->as<ompl::base::RealVectorStateSpace::StateType>();
				std::copy_n(rv->values, controlInputs, q.begin());
				return q;
			};

			double best = std::numeric_limits<double>::infinity();

			if (goal->hasType(GoalType::GOAL_STATE))
			{
				const GoalState *gs = goal->as<GoalState>();
				const State *gstate = gs->getState();
				if (!gstate)
					return Cost(std::numeric_limits<double>::infinity());

				const auto q_s = stateToTauLocal(s);
				const auto q_g = stateToTauLocal(gstate);
				const auto ends_s = this->m_CTR_model.get_s_ends(q_s);
				const auto ends_g = this->m_CTR_model.get_s_ends(q_g);

				const double term1 = std::fabs(ends_s[0UL] - ends_g[0UL]);
				const double term2 = std::fabs((ends_s[0UL] - ends_s[1UL]) - (ends_g[0UL] - ends_g[1UL]));
				const double term3 = std::fabs((ends_s[1UL] - ends_s[2UL]) - (ends_g[1UL] - ends_g[2UL]));
				const double term4 = std::fabs((ends_s[0UL] - ends_s[2UL]) - (ends_g[0UL] - ends_g[2UL]));

				best = c1 * term1 + c2 * term2 + c3 * term3 + c4 * term4;
			}
			else if (goal->hasType(GoalType::GOAL_STATES))
			{
				const GoalStates *gss = goal->as<GoalStates>();
				std::size_t count = gss->getStateCount();
				for (std::size_t i = 0; i < count; ++i)
				{
					const State *gs = gss->getState(i);
					if (!gs)
						continue;
					const auto q_s = stateToTauLocal(s);
					const auto q_g = stateToTauLocal(gs);
					const auto ends_s = this->m_CTR_model.get_s_ends(q_s);
					const auto ends_g = this->m_CTR_model.get_s_ends(q_g);

					const double term1 = std::fabs(ends_s[0UL] - ends_g[0UL]);
					const double term2 = std::fabs((ends_s[0UL] - ends_s[1UL]) - (ends_g[0UL] - ends_g[1UL]));
					const double term3 = std::fabs((ends_s[1UL] - ends_s[2UL]) - (ends_g[1UL] - ends_g[2UL]));
					const double term4 = std::fabs((ends_s[0UL] - ends_s[2UL]) - (ends_g[0UL] - ends_g[2UL]));

					const double val = c1 * term1 + c2 * term2 + c3 * term3 + c4 * term4;
					if (val < best)
						best = val;
				}
			}
			else
			{
				return Cost(std::numeric_limits<double>::infinity());
			}

			return Cost(best);
		};
		const Cost baseline = backboneBaseline(state, goal);

		// Helper to convert an ompl RealVector state to a blaze vector
		auto stateToTau = [this](const State *s)
		{
			blaze::StaticVector<double, controlInputs> q;
			if (!s)
				return q; // zero-initialized
			const auto *rv = s->as<ompl::base::RealVectorStateSpace::StateType>();
			std::copy_n(rv->values, controlInputs, q.begin());
			return q;
		};

		// Compute PINNs tip-distance heuristic to the goal. For single/sets of
		// goal states take the minimum tip distance. For other goal types fall
		// back to baseline's value.
		double pinn_min = std::numeric_limits<double>::infinity();

		if (!goal)
			return baseline;

		// current tip
		blaze::StaticVector<double, 3UL> tip_cur;
		const auto q_cur = stateToTau(state);
		try
		{
			this->m_CTR_model.get_pos_distal(q_cur, tip_cur);
		}
		catch (...) // be conservative: if PINNs fails, return baseline
		{
			return baseline;
		}

		if (goal->hasType(GoalType::GOAL_STATE))
		{
			const GoalState *gs = goal->as<GoalState>();
			const State *gstate = gs->getState();
			if (gstate)
			{
				const auto qg = stateToTau(gstate);
				blaze::StaticVector<double, 3UL> tip_goal;
				try
				{
					this->m_CTR_model.get_pos_distal(qg, tip_goal);
				}
				catch (...)
				{
					return baseline;
				}
				const double d = blaze::norm(tip_cur - tip_goal);
				pinn_min = std::min(pinn_min, d);
			}
		}
		else if (goal->hasType(GoalType::GOAL_STATES))
		{
			const GoalStates *gss = goal->as<GoalStates>();
			std::size_t count = gss->getStateCount();
			for (std::size_t i = 0; i < count; ++i)
			{
				const State *gs = gss->getState(i);
				if (!gs)
					continue;
				const auto qg = stateToTau(gs);
				blaze::StaticVector<double, 3UL> tip_goal;
				try
				{
					this->m_CTR_model.get_pos_distal(qg, tip_goal);
				}
				catch (...)
				{
					continue; // skip problematic goal states
				}
				const double d = blaze::norm(tip_cur - tip_goal);
				if (d < pinn_min)
					pinn_min = d;
			}
		}
		else
		{
			// For regions or sampleable regions we don't have an easy PINNs-based
			// heuristic, so fall back to baseline.
			return baseline;
		}

		if (pinn_min == std::numeric_limits<double>::infinity())
			return baseline;

		// Convert PINNs tip-distance (meters) to a conservative objective-unit
		// lower bound by multiplying by a small per-meter cost factor. We use
		// the smallest weight as a conservative conversion so units match and
		// admissibility is preserved.
		constexpr double per_meter_lower_bound = std::min(std::min(1000.0, 6000.0), std::min(3000.0, 500.0));
		const double pinn_converted = pinn_min * per_meter_lower_bound;

		// Return the minimum of the backbone baseline and the converted PINNs
		// heuristic to preserve admissibility while allowing tighter PINNs
		// guidance when available.
		const double best = std::min(baseline.value(), pinn_converted);
		return Cost(best); });

	return obj;
}

template <size_t Nodes, size_t controlInputs>
ompl::base::PlannerPtr Planner<Nodes, controlInputs>::allocatePlanner(optimalPlanner plannerType)
{
	switch (plannerType)
	{
	case optimalPlanner::PLANNER_AITSTAR:
	{
		return std::make_shared<ompl::geometric::AITstar>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_BFMTSTAR:
	{
		return std::make_shared<ompl::geometric::BFMT>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_BITSTAR:
	{
		return std::make_shared<ompl::geometric::BITstar>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_CFOREST:
	{
		return std::make_shared<ompl::geometric::CForest>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_FMTSTAR:
	{
		return std::make_shared<ompl::geometric::FMT>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_INF_RRTSTAR:
	{
		return std::make_shared<ompl::geometric::InformedRRTstar>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_PRMSTAR:
	{
		return std::make_shared<ompl::geometric::PRMstar>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_RRTSTAR:
	{
		return std::make_shared<ompl::geometric::RRTstar>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_SORRTSTAR:
	{
		return std::make_shared<ompl::geometric::SORRTstar>(this->m_si);
		break;
	}
	// NEW PLANNERS
	case optimalPlanner::PLANNER_PRM:
	{
		return std::make_shared<ompl::geometric::PRM>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_SPARS:
	{
		return std::make_shared<ompl::geometric::SPARS>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_RRT:
	{
		return std::make_shared<ompl::geometric::RRT>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_RRT_CONNECT:
	{
		return std::make_shared<ompl::geometric::RRTConnect>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_RRT_SHARP:
	{
		return std::make_shared<ompl::geometric::RRTsharp>(this->m_si);
		break;
	}
	case optimalPlanner::PLANNER_RLRT:
	{
		return std::make_shared<ompl::geometric::RLRT>(this->m_si);
		break;
	}
	default:
	{
		OMPL_ERROR("Planner-type enum is not implemented in allocation function.");
		return ompl::base::PlannerPtr(); // Address compiler warning re: no return value.
		break;
	}
	}
}

template <size_t Nodes, size_t controlInputs>
ompl::base::OptimizationObjectivePtr Planner<Nodes, controlInputs>::allocateObjective(planningObjective objectiveType)
{
	switch (objectiveType)
	{
	case planningObjective::OBJECTIVE_PATH_CLEARANCE:
		return getClearanceObjective();
		break;
	case planningObjective::OBJECTIVE_PATH_LENGTH:
		return getPathLengthObjective();
		break;
	case planningObjective::OBJECTIVE_REVJOINTS_AND_BACKBONE:
	{
		std::array<double, 3UL> revJointGoals = {
			m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>()->values[3UL],
			m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>()->values[4UL],
			m_goalState->get()->as<ompl::base::RealVectorStateSpace::StateType>()->values[5UL]};
		// Return the composite revolute+joints + backbone-length objective so
		// that allocInformedStateSampler can be forwarded to component
		// objectives (the backbone objective provides a direct InformedSampler).
		return RevoluteJointsAndBackboneLengthObjective(revJointGoals);
		break;
	}
	case planningObjective::OBJECTIVE_PATH_LENGTH_COST2GO:
		return getPathLengthObjWithCostToGo();
		break;
	case planningObjective::OBJECTIVE_THRESHOLD_PATH_LENGTH:
		return getThresholdPathLengthObjctive();
		break;
	case planningObjective::OBJECTIVE_WEIGHTED_COMBO:
		return getBalancedObjective();
		break;
	case planningObjective::OBJECTIVE_BACKBONE_LENGTH:
		return getBackboneLengthObjective();
		break;
	default:
		OMPL_ERROR("Optimization-objective enum is not implemented in allocation function.");
		return ompl::base::OptimizationObjectivePtr();
		break;
	}
}