#pragma once

#include <ompl/base/StateSampler.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/ScopedState.h>
#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/StateSampler.h>

#include <memory>
#include <cmath>

#include "CTR_SamplerUtils.hpp"
#include "PINNs.hpp"
#include "CTR_StateValidityChecker.hpp"

// A simple PINNs-informed state sampler that biases samples toward the goal
// tip position. This is NOT an OMPL InformedStateSampler subclass; instead it
// implements ompl::base::StateSampler and can be installed via
// setStateSamplerAllocator on the state space. It uses the PINNs forward model
// to compute tip positions and the PINNs::posCTRL (IK) routine to map a
// target tip back to a joint configuration. If IK or validity checks fail the
// sampler falls back to the provided uniform sampler.

template <size_t Nodes, size_t controlInputs>
class CTR_PINNsInformedSampler : public ompl::base::StateSampler
{
public:
    // ctor: space must outlive this sampler. fallbackSampler is used when the
    // informed approach fails; it can be the regular CTR_StateSampler.
    CTR_PINNsInformedSampler(const ompl::base::StateSpace *space,
                             CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker,
                             PINNs<Nodes, controlInputs> &ctr,
                             ompl::base::StateSamplerPtr fallbackSampler)
        : ompl::base::StateSampler(space), m_validityChecker(validityChecker), m_ctr(ctr), m_fallback(std::move(fallbackSampler))
    {
        // default bias: how often to attempt an informed sample [0..1]
        m_bias = 0.50;
        // default radius (meters) around goal tip used for sampling tip-space
        m_tipRadius = 0.005; // 0.5 cm by default; tune for your workspace
    }

    ~CTR_PINNsInformedSampler() override = default;

    // Set the desired bias (probability of generating informed samples)
    void setBias(double b) { m_bias = std::min(std::max(b, 0.00), 1.00); }

    // Set the tip-space sampling radius in meters
    void setTipRadius(double r) { m_tipRadius = std::max(r, 0.00); }

    // Set maximum informed attempts when trying IK-based samples
    void setMaxAttempts(int n) { m_maxAttempts = std::max(1, n); }

    // Provide the goal state so the sampler can compute goal tip position
    void setGoalState(const ompl::base::State *goal)
    {
        if (!goal)
        {
            m_hasGoal = false;
            return;
        }
        m_hasGoal = true;
        const auto *rv = goal->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            m_goalVec[i] = rv->values[i];
        // compute tip position for goal using PINNs
        try
        {
            m_ctr.get_pos_distal(m_goalVec, m_goalTip);
        }
        catch (...) // be conservative
        {
            m_hasGoal = false;
        }
    }

    // Primary sampling method called by OMPL
    void sampleUniform(ompl::base::State *state) override
    {
        // With probability m_bias attempt an informed sample; otherwise fallback
        const double u = rng_.uniformReal(0.00, 1.00);
        if (u > m_bias || !m_hasGoal)
        {
            if (m_fallback)
                m_fallback->sampleUniform(state);
            return;
        }

        // Attempt informed sample in tip-space with multiple tries: pick a random point within
        // a ball of radius m_tipRadius centered at the goal tip, then try to
        // solve IK (posCTRL) to obtain a joint configuration that reaches it.
        bool success = false;
        blaze::StaticVector<double, controlInputs> tauInit;
        for (int attempt = 0; attempt < m_maxAttempts; ++attempt)
        {
            blaze::StaticVector<double, 3UL> tipSample;
            randomPointInBall(rng_, m_goalTip, m_tipRadius, tipSample);

            tauInit = m_goalVec; // start from goal as initial guess
            try
            {
                m_ctr.posCTRL(tauInit, tipSample, 1.00E-3);
                success = true;
                break;
            }
            catch (...)
            {
                // try again
            }
        }

        if (!success)
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }

        // Build OMPL state from tauInit
        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        for (size_t i = 0; i < controlInputs; ++i)
            rv->values[i] = tauInit[i];

        // If state is invalid, fall back
        if (!m_validityChecker.isValid(state))
        {
            if (m_fallback)
            {
                m_fallback->sampleUniform(state);
                return;
            }
        }
    }

    void sampleUniformNear(ompl::base::State *state, const ompl::base::State *near, double distance) override
    {
        const auto *qnear = near->as<ompl::base::RealVectorStateSpace::StateType>();
        const auto *rvss  = space_->as<ompl::base::RealVectorStateSpace>();
        const auto &bounds = rvss->getBounds();
        const double clr  = m_ctr.getStageThickness();

        // Read near-state betas once as the stable reference.
        // Per-tube interval clamping preserves tube identity; sorting the
        // perturbed values would swap tube identities.
        const double b0n = qnear->values[0], b1n = qnear->values[1], b2n = qnear->values[2];

        const double lo0 = bounds.low[0],                        hi0 = std::min(bounds.high[0], b1n - clr);
        const double lo1 = std::max(bounds.low[1], b0n + clr),  hi1 = std::min(bounds.high[1], b2n - clr);
        const double lo2 = std::max(bounds.low[2], b1n + clr),  hi2 = bounds.high[2];

        auto clampPerturb = [&](double center, double lo, double hi) -> double
        {
            if (lo > hi) return (lo + hi) * 0.5;
            const double val = center + rng_.uniformReal(-distance, distance);
            return std::min(std::max(val, lo), hi);
        };

        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        rv->values[0] = clampPerturb(b0n, lo0, hi0);
        rv->values[1] = clampPerturb(b1n, lo1, hi1);
        rv->values[2] = clampPerturb(b2n, lo2, hi2);

        // Revolute joints: shortest-arc perturbation wrapped to [-π, π]
        for (size_t i = 3; i < controlInputs; ++i)
        {
            double val = qnear->values[i] + rng_.uniformReal(-distance, distance);
            while (val >  M_PI) val -= 2.0 * M_PI;
            while (val < -M_PI) val += 2.0 * M_PI;
            val = std::min(std::max(val, bounds.low[i]), bounds.high[i]);
            rv->values[i] = val;
        }

        if (!m_validityChecker.isValid(state) && m_fallback)
            m_fallback->sampleUniformNear(state, near, distance);
    }

    void sampleGaussian(ompl::base::State *state, const ompl::base::State *mean, double stdDev) override
    {
        const auto *qmean  = mean->as<ompl::base::RealVectorStateSpace::StateType>();
        const auto *rvss   = space_->as<ompl::base::RealVectorStateSpace>();
        const auto &bounds = rvss->getBounds();
        const double clr   = m_ctr.getStageThickness();

        // Read mean betas as reference for per-tube clamping.
        const double b0m = qmean->values[0], b1m = qmean->values[1], b2m = qmean->values[2];

        const double lo0 = bounds.low[0],                        hi0 = std::min(bounds.high[0], b1m - clr);
        const double lo1 = std::max(bounds.low[1], b0m + clr),  hi1 = std::min(bounds.high[1], b2m - clr);
        const double lo2 = std::max(bounds.low[2], b1m + clr),  hi2 = bounds.high[2];

        auto clampGauss = [&](double center, double lo, double hi) -> double
        {
            if (lo > hi) return (lo + hi) * 0.5;
            return std::min(std::max(center + rng_.gaussian(0.0, stdDev), lo), hi);
        };

        auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        rv->values[0] = clampGauss(b0m, lo0, hi0);
        rv->values[1] = clampGauss(b1m, lo1, hi1);
        rv->values[2] = clampGauss(b2m, lo2, hi2);

        // Revolute joints: Gaussian perturbation wrapped to [-π, π]
        for (size_t i = 3; i < controlInputs; ++i)
        {
            double val = qmean->values[i] + rng_.gaussian(0.0, stdDev);
            while (val >  M_PI) val -= 2.0 * M_PI;
            while (val < -M_PI) val += 2.0 * M_PI;
            val = std::min(std::max(val, bounds.low[i]), bounds.high[i]);
            rv->values[i] = val;
        }

        if (!m_validityChecker.isValid(state) && m_fallback)
            m_fallback->sampleGaussian(state, mean, stdDev);
    }

private:
    CTR_StateValidityChecker<Nodes, controlInputs> &m_validityChecker;
    PINNs<Nodes, controlInputs> &m_ctr;
    ompl::RNG rng_;
    ompl::base::StateSamplerPtr m_fallback;

    // goal info
    bool m_hasGoal{false};
    blaze::StaticVector<double, controlInputs> m_goalVec{};
    blaze::StaticVector<double, 3UL> m_goalTip{};

    double m_bias;      // probability to attempt informed sample
    double m_tipRadius; // meters
    int m_maxAttempts{10};

};