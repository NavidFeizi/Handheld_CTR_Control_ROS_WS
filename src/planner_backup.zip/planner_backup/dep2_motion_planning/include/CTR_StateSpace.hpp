#pragma once

#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <cmath>

// 6-DOF state space for a 3-tube Concentric Tube Robot.
//
// Dimensions 0-2 are prismatic joints (β₁, β₂, β₃): standard Euclidean
// metric and linear interpolation.
//
// Dimensions 3-5 are revolute joints (α₁, α₂, α₃): shortest-path angular
// distance and interpolation, so the planner correctly handles wrap-around
// at ±π instead of treating +170° and -170° as 340° apart.
//
// All existing state-access patterns using values[0..5] remain unchanged
// because CTRStateSpace inherits RealVectorStateSpace's StateType.
class CTRStateSpace : public ompl::base::RealVectorStateSpace
{
public:
    CTRStateSpace() : ompl::base::RealVectorStateSpace(6) {}

    // Distance: Euclidean for prismatic dims, shortest-path for revolute dims.
    double distance(const ompl::base::State *s1, const ompl::base::State *s2) const override
    {
        const auto *rv1 = s1->as<StateType>();
        const auto *rv2 = s2->as<StateType>();
        double sum = 0.0;

        // Prismatic (dims 0-2): standard Euclidean
        for (unsigned int i = 0; i < 3; ++i)
        {
            const double d = rv1->values[i] - rv2->values[i];
            sum += d * d;
        }

        // Revolute (dims 3-5): wrap difference to (-π, π]
        for (unsigned int i = 3; i < 6; ++i)
        {
            double d = rv1->values[i] - rv2->values[i];
            while (d >  M_PI) d -= 2.0 * M_PI;
            while (d < -M_PI) d += 2.0 * M_PI;
            sum += d * d;
        }

        return std::sqrt(sum);
    }

    // Interpolation: linear for prismatic, shortest-arc for revolute.
    void interpolate(const ompl::base::State *from, const ompl::base::State *to,
                     double t, ompl::base::State *state) const override
    {
        const auto *f = from->as<StateType>();
        const auto *g = to->as<StateType>();
        auto       *r = state->as<StateType>();

        // Prismatic: linear interpolation
        for (unsigned int i = 0; i < 3; ++i)
            r->values[i] = f->values[i] + t * (g->values[i] - f->values[i]);

        // Revolute: shortest-arc interpolation
        for (unsigned int i = 3; i < 6; ++i)
        {
            double diff = g->values[i] - f->values[i];
            while (diff >  M_PI) diff -= 2.0 * M_PI;
            while (diff < -M_PI) diff += 2.0 * M_PI;
            r->values[i] = f->values[i] + t * diff;
        }
    }
};
