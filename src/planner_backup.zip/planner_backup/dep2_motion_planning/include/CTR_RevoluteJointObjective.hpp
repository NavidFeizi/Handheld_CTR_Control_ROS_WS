#pragma once

#include <ompl/base/objectives/StateCostIntegralObjective.h>
#include <ompl/base/SpaceInformation.h>
#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <array>
#include <ompl/base/goals/GoalState.h>
#include <ompl/base/goals/GoalStates.h>
#include <cmath>

// Make CTR_StateSampler templated to match PINNs
template <size_t Nodes, size_t controlInputs>
class CTR_RevoluteJointObjective : public ompl::base::StateCostIntegralObjective
{
public:
    // Per-joint penalty weights used in stateCost() and the cost-to-go heuristic.
    // Declared public so callers (e.g. analyzeSolution) can reference them
    // directly instead of duplicating the values.
    static constexpr double c1 = 2000.0; // inner tube revolute weight
    static constexpr double c2 = 1000.0; // intermediate tube revolute weight
    static constexpr double c3 =  400.0; // outer tube revolute weight

    // Default progress-scaling parameters for the rear-loaded penalty curve.
    static constexpr double defaultProgressAlpha = 200.0;
    static constexpr double defaultProgressGamma =   1.1;

    CTR_RevoluteJointObjective(const ompl::base::SpaceInformationPtr &si, const std::array<double, 3UL> &goal);

    ompl::base::Cost stateCost(const ompl::base::State *state) const override;

    // Configure prismatic start/goal for progress estimation. If not set,
    // progress is computed relative to zero-to-current prismatic displacement.
    void setPrismaticStartGoal(const std::array<double, 3UL> &startPrism, const std::array<double, 3UL> &goalPrism)
    {
        m_prismaticStart = startPrism;
        m_prismaticGoal = goalPrism;
        m_havePrismaticBounds = true;
    }

    // Tunable parameters controlling how strongly revolute penalties are
    // increased as progress approaches the goal. A larger alpha increases
    // the late-motion penalty (so the planner prefers to finish revolute
    // motion earlier). Gamma controls the curvature (default 2 -> quadratic).
    void setProgressScalingParameters(double alpha, double gamma)
    {
        m_progressAlpha = std::max(0.00, alpha);
        m_progressGamma = std::max(0.00, gamma);
    }

private:
    std::array<double, 3UL> m_goal;
    // Optional prismatic start/goal for progress estimation
    std::array<double, 3UL> m_prismaticStart{0.00, 0.00, 0.00};
    std::array<double, 3UL> m_prismaticGoal{0.00, 0.00, 0.00};
    bool m_havePrismaticBounds{false};

    // Scaling parameters (retuned): reduce early amplification (alpha) and
    // slightly increase curvature (gamma) to avoid overwhelming backbone
    // cost while still penalizing very late rotation.
    double m_progressAlpha{defaultProgressAlpha};
    double m_progressGamma{defaultProgressGamma};

    // Compute progress in [0,1] along prismatic DOFs using projection onto the
    // start->goal vector. If bounds are not set, compute a simple normalized
    // distance from origin to goal.
    double computePrismaticProgress(const ompl::base::State *state) const
    {
        const auto *rv = state->as<ompl::base::RealVectorStateSpace::StateType>();
        double q[3];
        for (size_t i = 0; i < 3; ++i)
            q[i] = rv->values[i];

        double sx = m_prismaticStart[0];
        double sy = m_prismaticStart[1];
        double sz = m_prismaticStart[2];
        double gx = m_prismaticGoal[0];
        double gy = m_prismaticGoal[1];
        double gz = m_prismaticGoal[2];

        double vx = gx - sx;
        double vy = gy - sy;
        double vz = gz - sz;
        double denom = vx * vx + vy * vy + vz * vz;
        if (denom <= 1.00E-12)
        {
            // Fallback: use distance from origin to goal as normalization
            double distGoal2 = gx * gx + gy * gy + gz * gz;
            double distCur2 = q[0] * q[0] + q[1] * q[1] + q[2] * q[2];
            if (distGoal2 <= 1.00E-12)
                return 0.00;
            double p = std::sqrt(distCur2 / distGoal2);
            return std::min(1.00, std::max(0.00, p));
        }

        double wx = q[0] - sx;
        double wy = q[1] - sy;
        double wz = q[2] - sz;
        double dot = wx * vx + wy * vy + wz * vz;
        double p = dot / denom;
        if (p < 0.00)
            p = 0.00;
        if (p > 1.00)
            p = 1.00;
        return p;
    }
};

// ============================= Implementation =============================

// Provide a cost-to-go heuristic so informed planners can use it. The
// heuristic is an admissible underestimate: the weighted absolute
// difference in revolute joints between the current state and the goal
// state(s). It is cheap to compute and expressed in the same units as
// stateCost().
template <size_t Nodes, size_t controlInputs>
static ompl::base::Cost revoluteCostToGoalHelper(const ompl::base::State *state, const ompl::base::Goal *goal, const std::array<double, 3UL> &weights)
{
    using namespace ompl::base;
    if (!state || !goal)
        return Cost(0.00);

    auto angleDiff = [](double a, double b)
    {
        double d = a - b;
        while (d > M_PI)
            d -= 2.00 * M_PI;
        while (d < -M_PI)
            d += 2.00 * M_PI;
        return std::fabs(d);
    };

    auto getAngles = [](const State *s) -> blaze::StaticVector<double, 3UL>
    {
        blaze::StaticVector<double, 3UL> angs{0.00, 0.00, 0.00};
        if (!s)
            return angs;
        const auto *rv = s->as<RealVectorStateSpace::StateType>();
        angs[0UL] = rv->values[3UL];
        angs[1UL] = rv->values[4UL];
        angs[2UL] = rv->values[5UL];
        return angs;
    };

    // Single GOAL_STATE
    if (goal->hasType(GoalType::GOAL_STATE))
    {
        const GoalState *gs = goal->as<GoalState>();
        const State *gstate = gs->getState();
        if (!gstate)
            return Cost(0.00);
        auto ang_cur = getAngles(state);
        auto ang_g = getAngles(gstate);
        double cost = 0.00;
        cost += weights[0] * angleDiff(ang_cur[0], ang_g[0]);
        cost += weights[1] * angleDiff(ang_cur[1], ang_g[1]);
        cost += weights[2] * angleDiff(ang_cur[2], ang_g[2]);
        return Cost(cost);
    }

    // GOAL_STATES: minimum over set
    if (goal->hasType(GoalType::GOAL_STATES))
    {
        const GoalStates *gss = goal->as<GoalStates>();
        std::size_t count = gss->getStateCount();
        if (count == 0)
            return Cost(0.0);
        double best = std::numeric_limits<double>::infinity();
        auto ang_cur = getAngles(state);
        for (std::size_t i = 0; i < count; ++i)
        {
            const State *gs = gss->getState(i);
            if (!gs)
                continue;
            auto ang_g = getAngles(gs);
            double cost = 0.0;
            cost += weights[0] * angleDiff(ang_cur[0], ang_g[0]);
            cost += weights[1] * angleDiff(ang_cur[1], ang_g[1]);
            cost += weights[2] * angleDiff(ang_cur[2], ang_g[2]);
            if (cost < best)
                best = cost;
        }
        return Cost(best == std::numeric_limits<double>::infinity() ? 0.0 : best);
    }

    // Fall back: no heuristic available
    return Cost(0.00);
}

// Set a cost-to-go heuristic using the same per-joint weights as stateCost.
template <size_t Nodes, size_t controlInputs>
struct _RevoluteWeightsHolder
{
    // Keep the heuristic weights consistent with stateCost coefficients to
    // preserve admissibility and match the optimized metric after the recent
    // penalty reduction.
    static constexpr std::array<double, 3UL> weights = {1000.0, 500.0, 200.0};
};

template <size_t Nodes, size_t controlInputs>
const std::array<double, 3UL> _RevoluteWeightsHolder<Nodes, controlInputs>::weights;

template <size_t Nodes, size_t controlInputs>
CTR_RevoluteJointObjective<Nodes, controlInputs>::CTR_RevoluteJointObjective(const ompl::base::SpaceInformationPtr &si, const std::array<double, 3UL> &goal)
    : ompl::base::StateCostIntegralObjective(si, true), m_goal(goal)
{
    // Install a cheap, admissible cost-to-go heuristic that returns the
    // weighted angular distance to the goal (or minimum over a set of goals).
    auto weights = _RevoluteWeightsHolder<Nodes, controlInputs>::weights;
    this->setCostToGoHeuristic([weights](const ompl::base::State *s, const ompl::base::Goal *g) -> ompl::base::Cost
                               { return revoluteCostToGoalHelper<Nodes, controlInputs>(s, g, weights); });
}

template <size_t Nodes, size_t controlInputs>
ompl::base::Cost CTR_RevoluteJointObjective<Nodes, controlInputs>::stateCost(const ompl::base::State *state) const
{
    const auto *pos = state->as<ompl::base::RealVectorStateSpace::StateType>();

    // Penalize deviations for joints 3,4,5 (rotational).
    // Weights are public static constexpr members — no local duplication.

    // std::cout << "Revolute goal: [" << m_goal[0UL] << ", " << m_goal[1UL] << ", " << m_goal[2UL] << "]" << std::endl;

    // Use shortest-angle (wrapped) difference for revolute joints so the
    // cost matches the admissible heuristic's angular metric and avoids
    // large spurious costs near the ±pi wrap boundary.
    auto angleDiff = [](double a, double b)
    {
        double d = a - b;
        while (d > M_PI)
            d -= 2.0 * M_PI;
        while (d < -M_PI)
            d += 2.0 * M_PI;
        return std::fabs(d);
    };

    const double cost = c1 * angleDiff(pos->values[3UL], m_goal[0UL]) + c2 * angleDiff(pos->values[4UL], m_goal[1UL]) + c3 * angleDiff(pos->values[5UL], m_goal[2UL]);

    // Ordering (revolute-before-prismatic) is now enforced via the composite
    // objective's motionCost() override.  A flat per-state revolute penalty is
    // sufficient here; progress-based scaling is removed.
    return ompl::base::Cost(cost);
}