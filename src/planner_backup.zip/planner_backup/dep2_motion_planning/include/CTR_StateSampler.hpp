#pragma once

#include <ompl/base/State.h>
#include <ompl/base/StateSpace.h>
// #include <ompl/base/SpaceInformation.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/StateSampler.h>

#include <memory>
#include <cmath>
#include <iostream>
#include <algorithm>

#include "PINNs.hpp"
#include "CTR_StateValidityChecker.hpp"

// Make CTR_StateSampler templated to match PINNs
template <size_t Nodes, size_t controlInputs>
class CTR_StateSampler : public ompl::base::StateSampler
{
public:
    // // default constructor
    // CTR_StateSampler() = delete;

    // overloaded constructor
    CTR_StateSampler(const ompl::base::StateSpace *space, CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker, PINNs<Nodes, controlInputs> &ctr);

    // destructor
    ~CTR_StateSampler() override = default;

    // // copy constructor
    // CTR_StateSampler(const CTR_StateSampler &rhs);

    // // move constructor
    // CTR_StateSampler(CTR_StateSampler &&rhs);

    // // copy assignment operator
    // CTR_StateSampler &operator=(const CTR_StateSampler &rhs);

    // // move assignment operator
    // CTR_StateSampler &operator=(CTR_StateSampler &&rhs) noexcept;

    void sampleUniform(ompl::base::State *state) override;

    // Add these overrides:
    void sampleUniformNear(ompl::base::State *state, const ompl::base::State *near, double distance) override;

    void sampleGaussian(ompl::base::State *state, const ompl::base::State *mean, double stdDev) override;

    void setParameters(double b1, double b2, double b3, double clearance);

    void setGoalAngles(double a1, double a2, double a3);

protected:
    ompl::RNG rng_;

private:
    PINNs<Nodes, controlInputs> &m_ctr;
    CTR_StateValidityChecker<Nodes, controlInputs> &m_validityChecker;
    double m_beta1_Min, m_beta2_Min, m_beta3_Min;
    double m_alpha1_Min, m_alpha2_Min, m_alpha3_Min;
    double m_alpha1_max, m_alpha2_max, m_alpha3_max;
    double m_Clr; // minimum clearance between linear actuators
    // Goal angles (for rotation-focused sampling)
    double m_alpha1_goal{0.00}, m_alpha2_goal{0.00}, m_alpha3_goal{0.00};
};

// ============================= Implementation =============================

// overloaded constructor
template <size_t Nodes, size_t controlInputs>
CTR_StateSampler<Nodes, controlInputs>::CTR_StateSampler(const ompl::base::StateSpace *space, CTR_StateValidityChecker<Nodes, controlInputs> &validityChecker, PINNs<Nodes, controlInputs> &ctr) : ompl::base::StateSampler(space), m_validityChecker(validityChecker), m_ctr(ctr)
{
    m_Clr = this->m_ctr.getStageThickness();
    // setting the minimum allowable actuation value for the linear joints
    const blaze::StaticVector<double, controlInputs> prismaticRanges = this->m_ctr.getPrismaticJointRanges();

    m_beta1_Min = prismaticRanges[0UL];
    m_beta2_Min = prismaticRanges[2UL];
    m_beta3_Min = prismaticRanges[4UL];

    // setting the allowable range for the revolute joints
    const blaze::StaticVector<double, controlInputs> revoluteRanges = this->m_ctr.getRevoluteJointRanges();

    m_alpha1_Min = revoluteRanges[0UL];
    m_alpha1_max = revoluteRanges[1UL];

    m_alpha2_Min = revoluteRanges[2UL];
    m_alpha2_max = revoluteRanges[3UL];

    m_alpha3_Min = revoluteRanges[4UL];
    m_alpha3_max = revoluteRanges[5UL];

    // std::cout << "----------------- CTR_StateSampler Summary ----------------" << std::endl;
    // std::cout << "Linear Joint Minimums: Beta1_Min = " << m_beta1_Min << " | Beta2_Min = " << m_beta2_Min << " | Beta3_Min = " << m_beta3_Min << std::endl;
    // std::cout << "Revolute Joint Ranges: \nAlpha1 = [" << m_alpha1_Min << ", " << m_alpha1_max << "] \nAlpha2 = [" << m_alpha2_Min << ", " << m_alpha2_max << "] \nAlpha3 = [" << m_alpha3_Min << ", " << m_alpha3_max << "]" << std::endl;

    // std::cout << "Sampler: CTR_StateSampler" << std::endl;
}

// // Copy Constructor
// CTR_StateSampler<Nodes, controlInputs>::CTR_StateSampler(const CTR_StateSampler &other)
//     : ValidStateSampler(other.si_)
// {
//    // Copy over any member variables if needed
//    this->rng_ = other.rng_;
//    this->beta1_Min = other.m_beta1_Min;
//    this->beta2_Min = other.m_beta2_Min;
//    this->beta3_Min = other.m_beta3_Min;
//    this->m_Clr = other.m_Clr;
// }

template <size_t Nodes, size_t controlInputs>
void CTR_StateSampler<Nodes, controlInputs>::sampleUniform(ompl::base::State *state)
{
    // std::cout << "CTR_StateSampler called!" << std::endl;

    ompl::base::RealVectorStateSpace::StateType *sampled_State = state->as<ompl::base::RealVectorStateSpace::StateType>();

    // Get beta goals directly from the validity checker
    const double beta1_goal = this->m_validityChecker.getBeta1Goal();
    const double beta2_goal = this->m_validityChecker.getBeta2Goal();
    const double beta3_goal = this->m_validityChecker.getBeta3Goal();

    /*
    Sampling strategy:

    - Betas are sampled in three phases:
            Phase 1 (95%): Full exploration toward goals.
            Phase 2 (4%):   Beta3 fixed at goal.
            Phase 3 (1%):   Beta2 and Beta3 fixed.
        This creates a progressively goal-biased prismatic sampling.

    - Rotations:
            During early insertion sampling: uniform.
            After 15% insertion progress: occasionally Gaussian goal-biased (25% chance).
    */

    // ================= Prismatic joint sampling =================

    // Randomly select a phase to sample from
    const double u = rng_.uniformReal(0.00, 1.00);

    // decide phase with desired weights:
    size_t phase;

    if (u < 0.95)      
        phase = 1;     // phase 1: 95% selected of the time
    else if (u < 0.99) 
        phase = 2;     // phase 2: 4% selected of the time
    else
        phase = 3; // phase 3: 1% selected of the time

    double beta_1, beta_2, beta_3;

    // sampling the linear joints ensuring that beta_1 < beta_2 < beta_3
    switch (phase)
    {
    case 1: // Phase 1: All betas evolve independently
        beta_1 = rng_.uniformReal(m_beta1_Min, beta1_goal);
        beta_2 = rng_.uniformReal(std::max(m_beta2_Min, beta_1 + m_Clr), beta2_goal);
        beta_3 = rng_.uniformReal(std::max(m_beta3_Min, beta_2 + m_Clr), beta3_goal);
        break;
    case 2: // Phase 2: Beta3 fixed, beta1, beta2 evolve independently
        beta_3 = beta3_goal;
        beta_2 = rng_.uniformReal(m_beta2_Min, beta2_goal);
        beta_1 = rng_.uniformReal(m_beta1_Min, std::min(beta1_goal, beta_2 - m_Clr));
        break;
    case 3: // Phase 3: Beta3, beta2 fixed, beta1 varies
        beta_3 = beta3_goal;
        beta_2 = beta2_goal;
        beta_1 = rng_.uniformReal(m_beta1_Min, beta1_goal);
        break;
    }

    sampled_State->values[0UL] = beta_1;
    sampled_State->values[1UL] = beta_2;
    sampled_State->values[2UL] = beta_3;

    // ================= Revolute joint sampling =================
    // Determine prismatic progress (average normalized toward goals)
    double progressBeta = 0.00;
    if (beta1_goal > m_beta1_Min && beta2_goal > m_beta2_Min && beta3_goal > m_beta3_Min)
    {
        double f1 = (beta_1 - m_beta1_Min) / std::max(1.00E-9, beta1_goal - m_beta1_Min);
        double f2 = (beta_2 - m_beta2_Min) / std::max(1.00E-9, beta2_goal - m_beta2_Min);
        double f3 = (beta_3 - m_beta3_Min) / std::max(1.00E-9, beta3_goal - m_beta3_Min);
        progressBeta = (f1 + f2 + f3) / 3.00;
        progressBeta = std::clamp(progressBeta, 0.00, 1.00);
    }

    // Bias revolute sampling toward goal angles.
    // Two complementary modes:
    //   revolveFirst (25%): revolute joints near goal regardless of prismatic progress.
    //     These are the key waypoints for a "rotate-before-deploy" path: (early β, goal α).
    //     Without them the planner's tree never contains the necessary waypoints and the
    //     optimizer cannot route through a revolute-first trajectory regardless of the cost.
    //   rotationFocus (33% of remaining, only after 15% deployment): fine-grained
    //     goal-biased revolute sampling once insertion has started.
    const bool goalsSet = (std::fabs(m_alpha1_goal) > 1.00E-9 || std::fabs(m_alpha2_goal) > 1.00E-9 || std::fabs(m_alpha3_goal) > 1.00E-9);
    const bool revolveFirst  = goalsSet && (rng_.uniformReal(0.00, 1.00) < 0.25);
    const bool rotationFocus = !revolveFirst && goalsSet && (progressBeta > 0.15) && (rng_.uniformReal(0.00, 1.00) < 0.3333);
    constexpr double rotStd = 0.174533; // 10 degrees standard deviation
    if (revolveFirst || rotationFocus)
    {
        auto wrapClamp = [](double v, double lo, double hi) -> double {
            while (v >  M_PI) v -= 2.0 * M_PI;
            while (v < -M_PI) v += 2.0 * M_PI;
            return std::min(std::max(v, lo), hi);
        };
        sampled_State->values[3UL] = wrapClamp(rng_.gaussian(m_alpha1_goal, rotStd), m_alpha1_Min, m_alpha1_max);
        sampled_State->values[4UL] = wrapClamp(rng_.gaussian(m_alpha2_goal, rotStd), m_alpha2_Min, m_alpha2_max);
        sampled_State->values[5UL] = wrapClamp(rng_.gaussian(m_alpha3_goal, rotStd), m_alpha3_Min, m_alpha3_max);
    }
    else
    {
        // Uniform sampling within bounds (original behavior)
        sampled_State->values[3UL] = rng_.uniformReal(m_alpha1_Min, m_alpha1_max);
        sampled_State->values[4UL] = rng_.uniformReal(m_alpha2_Min, m_alpha2_max);
        sampled_State->values[5UL] = rng_.uniformReal(m_alpha3_Min, m_alpha3_max);
    }
}

template <size_t Nodes, size_t controlInputs>
void CTR_StateSampler<Nodes, controlInputs>::sampleUniformNear(ompl::base::State *state, const ompl::base::State *near, double distance)
{
    auto       *q  = state->as<ompl::base::RealVectorStateSpace::StateType>();
    const auto *qn = near->as<ompl::base::RealVectorStateSpace::StateType>();

    // Read the near-state betas once as the stable reference.
    // Per-tube interval clamping preserves tube identity: β0 stays β0, etc.
    // Sorting the perturbed values (old approach) would swap tube identities
    // (e.g., the perturbed β0 could end up at the old β2 position).
    const double b0n = qn->values[0], b1n = qn->values[1], b2n = qn->values[2];

    const double beta1_goal = this->m_validityChecker.getBeta1Goal();
    const double beta2_goal = this->m_validityChecker.getBeta2Goal();
    const double beta3_goal = this->m_validityChecker.getBeta3Goal();

    // Valid interval for each tube derived from joint limits and the near
    // state's neighbours, ensuring ordering is maintained after perturbation.
    const double lo0 = m_beta1_Min,                             hi0 = std::min(beta1_goal, b1n - m_Clr);
    const double lo1 = std::max(m_beta2_Min, b0n + m_Clr),     hi1 = std::min(beta2_goal, b2n - m_Clr);
    const double lo2 = std::max(m_beta3_Min, b1n + m_Clr),     hi2 = beta3_goal;

    auto clampPerturb = [&](double center, double lo, double hi) -> double
    {
        if (lo > hi) return (lo + hi) * 0.5; // degenerate interval: use midpoint
        const double val = center + rng_.uniformReal(-distance, distance);
        return std::min(std::max(val, lo), hi);
    };

    q->values[0] = clampPerturb(b0n, lo0, hi0);
    q->values[1] = clampPerturb(b1n, lo1, hi1);
    q->values[2] = clampPerturb(b2n, lo2, hi2);

    // Revolute joints: shortest-arc perturbation, clamped to declared bounds.
    const double alphaMin[3] = {m_alpha1_Min, m_alpha2_Min, m_alpha3_Min};
    const double alphaMax[3] = {m_alpha1_max, m_alpha2_max, m_alpha3_max};
    for (size_t i = 3; i < 6; ++i)
    {
        double val = qn->values[i] + rng_.uniformReal(-distance, distance);
        while (val >  M_PI) val -= 2.0 * M_PI;
        while (val < -M_PI) val += 2.0 * M_PI;
        val = std::min(std::max(val, alphaMin[i - 3]), alphaMax[i - 3]);
        q->values[i] = val;
    }
}

// Sample with Gaussian distribution around a mean state
template <size_t Nodes, size_t controlInputs>
void CTR_StateSampler<Nodes, controlInputs>::sampleGaussian(ompl::base::State *state, const ompl::base::State *mean, double stdDev)
{
    auto *q  = state->as<ompl::base::RealVectorStateSpace::StateType>();
    auto *qm = mean->as<ompl::base::RealVectorStateSpace::StateType>();

    const double beta1_goal = m_validityChecker.getBeta1Goal();
    const double beta2_goal = m_validityChecker.getBeta2Goal();
    const double beta3_goal = m_validityChecker.getBeta3Goal();

    // Prismatic joints: per-tube Gaussian + clamp to valid interval derived
    // from the mean state's neighbours. Sorting the perturbed values swaps
    // tube identities; per-tube clamping preserves them.
    const double b0m = qm->values[0], b1m = qm->values[1], b2m = qm->values[2];
    const double lo0 = m_beta1_Min,                         hi0 = std::min(beta1_goal, b1m - m_Clr);
    const double lo1 = std::max(m_beta2_Min, b0m + m_Clr),  hi1 = std::min(beta2_goal, b2m - m_Clr);
    const double lo2 = std::max(m_beta3_Min, b1m + m_Clr),  hi2 = beta3_goal;

    auto clampGauss = [&](double center, double lo, double hi) -> double
    {
        if (lo > hi) return (lo + hi) * 0.5;
        return std::min(std::max(center + rng_.gaussian(0.0, stdDev), lo), hi);
    };

    q->values[0] = clampGauss(b0m, lo0, hi0);
    q->values[1] = clampGauss(b1m, lo1, hi1);
    q->values[2] = clampGauss(b2m, lo2, hi2);

    // Revolute joints: Gaussian perturbation wrapped to [-π, π] then clamped.
    const double alphaMin[3] = {m_alpha1_Min, m_alpha2_Min, m_alpha3_Min};
    const double alphaMax[3] = {m_alpha1_max, m_alpha2_max, m_alpha3_max};
    for (size_t i = 3; i < controlInputs; ++i)
    {
        double val = qm->values[i] + rng_.gaussian(0.0, stdDev);
        while (val >  M_PI) val -= 2.0 * M_PI;
        while (val < -M_PI) val += 2.0 * M_PI;
        val = std::min(std::max(val, alphaMin[i - 3]), alphaMax[i - 3]);
        q->values[i] = val;
    }
}

template <size_t Nodes, size_t controlInputs>
void CTR_StateSampler<Nodes, controlInputs>::setParameters(double b1, double b2, double b3, double clearance)
{
    this->m_beta1_Min = b1;
    this->m_beta2_Min = b2;
    this->m_beta3_Min = b3;
    this->m_Clr = clearance;
}

template <size_t Nodes, size_t controlInputs>
void CTR_StateSampler<Nodes, controlInputs>::setGoalAngles(double a1, double a2, double a3)
{
    this->m_alpha1_goal = a1;
    this->m_alpha2_goal = a2;
    this->m_alpha3_goal = a3;
}